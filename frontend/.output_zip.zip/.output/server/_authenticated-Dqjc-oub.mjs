import { r as __toESM } from "./_runtime.mjs";
import { r as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as Truck, n as Wifi, r as WifiOff, x as Gauge } from "./_libs/lucide-react.mjs";
import { o as LoadingState, r as ErrorState } from "./_ssr/spinner-muDgHEuQ.mjs";
import { s as useVehicles } from "./_ssr/useVehicles-Bwt4z13w.mjs";
import { n as useVehicleStore } from "./_ssr/vehicleStore-CQijUHLr.mjs";
import { t as useMergedVehicles } from "./_ssr/useMergedVehicles-kPiaX86R.mjs";
import { o as formatSpeed, s as relativeTime } from "./_ssr/format-Dbvgyw5I.mjs";
import { t as VehicleStatusBadge } from "./_ssr/VehicleStatusBadge-B7pv-ZBP.mjs";
import { t as FleetMap } from "./_ssr/FleetMap-Wwx9Unqf.mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated-Dqjc-oub.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StatsCards({ vehicles }) {
	const total = vehicles.length;
	const online = vehicles.filter((v) => v.live?.status === "online").length;
	const offline = total - online;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-1 gap-4 sm:grid-cols-3",
		children: [
			{
				label: "Total Vehicles",
				value: total,
				icon: Truck,
				tone: "text-foreground",
				bg: "bg-primary/10 text-primary"
			},
			{
				label: "Online",
				value: online,
				icon: Wifi,
				tone: "text-emerald-600 dark:text-emerald-400",
				bg: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
			},
			{
				label: "Offline",
				value: offline,
				icon: WifiOff,
				tone: "text-muted-foreground",
				bg: "bg-muted text-muted-foreground"
			}
		].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-border bg-card p-5 shadow-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium text-muted-foreground",
					children: c.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `flex h-9 w-9 items-center justify-center rounded-lg ${c.bg}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(c.icon, { className: "h-5 w-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `mt-3 text-3xl font-bold ${c.tone}`,
				children: c.value
			})]
		}, c.label))
	});
}
function LiveActivityFeed({ vehicles }) {
	const recent = [...vehicles].filter((v) => v.live).sort((a, b) => new Date(b.live.lastSeenAt).getTime() - new Date(a.live.lastSeenAt).getTime()).slice(0, 8);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-b border-border px-5 py-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold",
				children: "Recent Activity"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "divide-y divide-border",
			children: [recent.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "px-5 py-6 text-sm text-muted-foreground",
				children: "No recent updates."
			}), recent.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/vehicles/$id",
				params: { id: v.id },
				className: "flex items-center gap-3 px-5 py-3 hover:bg-accent/50",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-medium",
							children: v.vehicleName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs text-muted-foreground",
							children: v.vehicleNumber
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "h-3.5 w-3.5" }), formatSpeed(v.live?.speed)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-xs text-muted-foreground sm:inline",
						children: relativeTime(v.live?.lastSeenAt)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleStatusBadge, { status: v.live?.status })
				]
			}) }, v.id))]
		})]
	});
}
function DashboardPage() {
	const { data, isLoading, isError, error, refetch } = useVehicles();
	const syncFromVehicles = useVehicleStore((s) => s.syncFromVehicles);
	const merged = useMergedVehicles(data);
	(0, import_react.useEffect)(() => {
		if (data) syncFromVehicles(data);
	}, [data, syncFromVehicles]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl space-y-6 p-4 sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-bold tracking-tight",
			children: "Fleet Dashboard"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Realtime overview of your fleet."
		})] }), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Loading fleet…" }) : isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
			message: error?.message,
			onRetry: () => refetch()
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsCards, { vehicles: merged }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-6 lg:grid-cols-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "overflow-hidden rounded-xl border border-border bg-card shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-border px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold",
							children: "Live Map"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/map",
							className: "text-xs font-medium text-primary hover:underline",
							children: "Open full map →"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FleetMap, {
						vehicles: merged,
						className: "h-[360px] w-full"
					})]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveActivityFeed, { vehicles: merged })]
		})] })]
	});
}
function Index() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardPage, {});
}
//#endregion
export { Index as component };
