import { t as arrayType } from "../_libs/zod.mjs";
import { a as LiveStateSchema, c as VehicleSchema, i as HistorySchema, s as RouteSummarySchema, t as CreateVehicleResponseSchema } from "./spinner-muDgHEuQ.mjs";
import { l as patch, o as get, u as post } from "./client-DUvhSboa.mjs";
import { n as useQuery, t as queryOptions } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useVehicles-Bwt4z13w.js
async function fetchVehicles() {
	const data = await get("/api/v1/vehicles");
	return arrayType(VehicleSchema).parse(data);
}
async function createVehicle(input) {
	const data = await post("/api/v1/vehicles", input);
	return CreateVehicleResponseSchema.parse(data);
}
async function fetchVehicle(id) {
	const data = await get(`/api/v1/vehicles/${id}`);
	return VehicleSchema.parse(data);
}
async function updateVehicle(id, input) {
	const data = await patch(`/api/v1/vehicles/${id}`, input);
	return VehicleSchema.parse(data);
}
async function fetchVehicleLive(id) {
	const data = await get(`/api/v1/vehicles/${id}/live`);
	return LiveStateSchema.parse(data);
}
async function fetchVehicleHistory(id, start, end, options) {
	const params = new URLSearchParams({
		start,
		end
	});
	if (options?.downsample && options.downsample > 1) params.set("downsample", String(options.downsample));
	const data = await get(`/api/v1/vehicles/${id}/history?${params.toString()}`);
	return HistorySchema.parse(data);
}
async function fetchVehicleHistorySummary(id, start, end) {
	const data = await get(`/api/v1/vehicles/${id}/history/summary?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`);
	return RouteSummarySchema.parse(data);
}
var vehiclesQueryOptions = () => queryOptions({
	queryKey: ["vehicles"],
	queryFn: fetchVehicles,
	staleTime: 3e4
});
var vehicleQueryOptions = (id) => queryOptions({
	queryKey: ["vehicle", id],
	queryFn: () => fetchVehicle(id),
	staleTime: 3e4
});
var vehicleLiveQueryOptions = (id) => queryOptions({
	queryKey: ["vehicle-live", id],
	queryFn: () => fetchVehicleLive(id),
	refetchInterval: 3e4
});
function useVehicles() {
	return useQuery(vehiclesQueryOptions());
}
function useVehicle(id) {
	return useQuery(vehicleQueryOptions(id));
}
function useVehicleLive(id) {
	return useQuery(vehicleLiveQueryOptions(id));
}
//#endregion
export { useVehicle as a, updateVehicle as i, fetchVehicleHistory as n, useVehicleLive as o, fetchVehicleHistorySummary as r, useVehicles as s, createVehicle as t };
