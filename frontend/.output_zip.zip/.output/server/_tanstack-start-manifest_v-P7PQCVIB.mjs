//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-P7PQCVIB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/app/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/login",
			"/register",
			"/sitemap.xml"
		],
		preloads: [
			"/assets/index-8Mwg41Z9.js",
			"/assets/client-CrY19GUP.js",
			"/assets/link-ITxB0P9L.js",
			"/assets/matchContext-Bu-3Akaj.js",
			"/assets/useRouter-D_ZGALQC.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-8Mwg41Z9.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/app/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/map",
			"/_authenticated/profile",
			"/_authenticated/users",
			"/_authenticated/",
			"/_authenticated/vehicles/",
			"/_authenticated/vehicles/$id/history",
			"/_authenticated/vehicles/$id/playback",
			"/_authenticated/vehicles/$id/"
		],
		preloads: [
			"/assets/route-Cn96KX32.js",
			"/assets/utils-B6KiDbIe.js",
			"/assets/createLucideIcon-deCkT3bJ.js",
			"/assets/spinner-DJ55cKAp.js",
			"/assets/truck-D_QCmOGD.js",
			"/assets/wifi-Cj8x2l29.js",
			"/assets/x-35hMZT4w.js",
			"/assets/vehicleStore-BQivdLGV.js"
		]
	},
	"/login": {
		filePath: "/app/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DRd0Oh1o.js",
			"/assets/label-enPr-Fp6.js",
			"/assets/truck-D_QCmOGD.js"
		]
	},
	"/register": {
		filePath: "/app/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-BowL5zbG.js",
			"/assets/label-enPr-Fp6.js",
			"/assets/truck-D_QCmOGD.js"
		]
	},
	"/_authenticated/map": {
		filePath: "/app/src/routes/_authenticated/map.tsx",
		children: void 0,
		css: ["/assets/maplibre-gl-B2k4QVOw.css"],
		preloads: [
			"/assets/map-BKxqs4ou.js",
			"/assets/useVehicles-BvK5Zom2.js",
			"/assets/FleetMap-Cw_vEqHl.js",
			"/assets/VehicleStatusBadge-_uS5L7iR.js",
			"/assets/useMergedVehicles-XmBlcNHt.js",
			"/assets/format-D2sGkcQe.js"
		]
	},
	"/_authenticated/profile": {
		filePath: "/app/src/routes/_authenticated/profile.tsx",
		children: void 0,
		preloads: ["/assets/profile-DYqJ_GE3.js", "/assets/label-enPr-Fp6.js"]
	},
	"/_authenticated/users": {
		filePath: "/app/src/routes/_authenticated/users.tsx",
		children: void 0,
		preloads: [
			"/assets/users-B4D01jHw.js",
			"/assets/label-enPr-Fp6.js",
			"/assets/useVehicles-BvK5Zom2.js"
		]
	},
	"/_authenticated/": {
		filePath: "/app/src/routes/_authenticated/index.tsx",
		children: void 0,
		css: ["/assets/maplibre-gl-B2k4QVOw.css"],
		preloads: [
			"/assets/_authenticated-c-Guq_nC.js",
			"/assets/useVehicles-BvK5Zom2.js",
			"/assets/gauge-BkVkiKb8.js",
			"/assets/FleetMap-Cw_vEqHl.js",
			"/assets/VehicleStatusBadge-_uS5L7iR.js",
			"/assets/useMergedVehicles-XmBlcNHt.js",
			"/assets/format-D2sGkcQe.js"
		]
	},
	"/_authenticated/vehicles/": {
		filePath: "/app/src/routes/_authenticated/vehicles.index.tsx",
		children: void 0,
		preloads: [
			"/assets/vehicles.index-6_gONoHW.js",
			"/assets/label-enPr-Fp6.js",
			"/assets/useVehicles-BvK5Zom2.js",
			"/assets/gauge-BkVkiKb8.js",
			"/assets/map-pin-LhR3ukPj.js",
			"/assets/navigation-C4p1oyr_.js",
			"/assets/VehicleStatusBadge-_uS5L7iR.js",
			"/assets/useMergedVehicles-XmBlcNHt.js",
			"/assets/format-D2sGkcQe.js"
		]
	},
	"/_authenticated/vehicles/$id/history": {
		filePath: "/app/src/routes/_authenticated/vehicles.$id.history.tsx",
		children: void 0,
		css: ["/assets/maplibre-gl-B2k4QVOw.css"],
		preloads: [
			"/assets/vehicles._id.history-BJhZ1uky.js",
			"/assets/useVehicles-BvK5Zom2.js",
			"/assets/arrow-left-tzjZZShG.js",
			"/assets/gauge-BkVkiKb8.js",
			"/assets/map-pin-LhR3ukPj.js",
			"/assets/maplibre-gl-D7QpM4b2.js",
			"/assets/format-D2sGkcQe.js"
		]
	},
	"/_authenticated/vehicles/$id/playback": {
		filePath: "/app/src/routes/_authenticated/vehicles.$id.playback.tsx",
		children: void 0,
		preloads: ["/assets/vehicles._id.playback-DJ7LAi8J.js"]
	},
	"/_authenticated/vehicles/$id/": {
		filePath: "/app/src/routes/_authenticated/vehicles.$id.index.tsx",
		children: void 0,
		css: ["/assets/maplibre-gl-B2k4QVOw.css"],
		preloads: [
			"/assets/vehicles._id.index-DAKqqvsn.js",
			"/assets/label-enPr-Fp6.js",
			"/assets/useVehicles-BvK5Zom2.js",
			"/assets/arrow-left-tzjZZShG.js",
			"/assets/gauge-BkVkiKb8.js",
			"/assets/map-pin-LhR3ukPj.js",
			"/assets/navigation-C4p1oyr_.js",
			"/assets/FleetMap-Cw_vEqHl.js",
			"/assets/VehicleStatusBadge-_uS5L7iR.js",
			"/assets/format-D2sGkcQe.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
