import { r as __toESM } from "../_runtime.mjs";
import { r as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as stringType, s as objectType, t as arrayType } from "../_libs/zod.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { o as LoadingState, r as ErrorState } from "./spinner-muDgHEuQ.mjs";
import { l as patch, o as get, t as ApiError, u as post } from "./client-DUvhSboa.mjs";
import { i as useQueryClient, n as useQuery, t as queryOptions } from "../_libs/tanstack__react-query.mjs";
import { s as useVehicles } from "./useVehicles-Bwt4z13w.mjs";
import { r as useAuth } from "./AuthContext-CIziQDdM.mjs";
import { n as Input, r as Label, t as Button } from "./label-BxvS4Y9r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/users-CscFgbT-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var UserWithVehiclesSchema = objectType({
	id: stringType(),
	email: stringType(),
	name: stringType().nullable().optional(),
	role: stringType(),
	status: stringType().optional(),
	createdAt: stringType(),
	vehicleIds: arrayType(stringType())
});
async function fetchUsers() {
	const data = await get("/api/v1/users");
	return arrayType(UserWithVehiclesSchema).parse(data);
}
async function createUser(input) {
	const data = await post("/api/v1/users", input);
	return UserWithVehiclesSchema.parse(data);
}
async function updateUser(id, input) {
	const data = await patch(`/api/v1/users/${id}`, input);
	return UserWithVehiclesSchema.parse(data);
}
var usersQueryOptions = () => queryOptions({
	queryKey: ["users"],
	queryFn: fetchUsers,
	staleTime: 3e4
});
function useUsers() {
	return useQuery(usersQueryOptions());
}
function UsersPage() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const isAdmin = user?.role === "admin";
	const usersQuery = useUsers();
	const vehiclesQuery = useVehicles();
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [vehicleIds, setVehicleIds] = (0, import_react.useState)([]);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const vehicles = vehiclesQuery.data ?? [];
	const users = usersQuery.data ?? [];
	const assignedVehicleIds = (0, import_react.useMemo)(() => {
		const set = /* @__PURE__ */ new Set();
		for (const u of users) for (const id of u.vehicleIds) set.add(id);
		return set;
	}, [users]);
	const vehicleOptions = (0, import_react.useMemo)(() => vehicles.map((v) => ({
		id: v.id,
		label: `${v.vehicleName} (${v.vehicleNumber})`,
		assigned: assignedVehicleIds.has(v.id)
	})), [vehicles, assignedVehicleIds]);
	if (!isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-3xl p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, { message: "Forbidden" })
	});
	if (usersQuery.isLoading || vehiclesQuery.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Loading users…" });
	if (usersQuery.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
		message: usersQuery.error?.message,
		onRetry: () => usersQuery.refetch()
	});
	const onCreate = async (e) => {
		e.preventDefault();
		setSubmitting(true);
		setError(null);
		try {
			await createUser({
				email,
				password,
				name: name.trim() || void 0,
				role: "viewer",
				vehicleIds
			});
			setEmail("");
			setPassword("");
			setName("");
			setVehicleIds([]);
			await queryClient.invalidateQueries({ queryKey: ["users"] });
		} catch (err) {
			setError(err instanceof ApiError ? err.message : "Unable to create user.");
		} finally {
			setSubmitting(false);
		}
	};
	const toggleVehicle = (id) => {
		setVehicleIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
	};
	const assignVehicles = async (userId, ids) => {
		try {
			await updateUser(userId, { vehicleIds: ids });
			await queryClient.invalidateQueries({ queryKey: ["users"] });
		} catch (err) {
			setError(err instanceof ApiError ? err.message : "Unable to update user.");
		}
	};
	const setUserStatus = async (userId, status) => {
		try {
			await updateUser(userId, { status });
			await queryClient.invalidateQueries({ queryKey: ["users"] });
		} catch (err) {
			setError(err instanceof ApiError ? err.message : "Unable to update user.");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl space-y-6 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold tracking-tight text-foreground",
				children: "Users"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Create users and assign vehicles. Non-admin users only see assigned vehicles."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border bg-card p-6 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold text-foreground",
					children: "Create user"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: onCreate,
					className: "mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "email",
								children: "Email"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "email",
								value: email,
								onChange: (e) => setEmail(e.target.value),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "password",
								children: "Temporary password"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "password",
								type: "password",
								value: password,
								onChange: (e) => setPassword(e.target.value),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "name",
								children: "Name (optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "name",
								value: name,
								onChange: (e) => setName(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Assign vehicles" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 gap-2 sm:grid-cols-2",
								children: [vehicleOptions.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 rounded-md border border-border bg-background px-3 py-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: vehicleIds.includes(v.id),
										onChange: () => toggleVehicle(v.id)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "min-w-0 truncate",
										children: v.label
									})]
								}, v.id)), vehicleOptions.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: "No vehicles yet. Create vehicles first."
								})]
							})]
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "sm:col-span-2 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sm:col-span-2 flex justify-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: submitting,
								children: submitting ? "Creating…" : "Create user"
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border bg-card shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-b border-border px-6 py-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold text-foreground",
						children: "Organization users"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "divide-y divide-border",
					children: [users.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRow, {
						user: u,
						vehicleOptions,
						onAssign: assignVehicles,
						onSetStatus: setUserStatus
					}, u.id)), users.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-6 py-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "No users yet."
						})
					})]
				})]
			})
		]
	});
}
function UserRow({ user, vehicleOptions, onAssign, onSetStatus }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)(user.vehicleIds);
	const isViewer = user.role === "viewer";
	const status = user.status ?? "active";
	const toggle = (id) => {
		setSelected((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
	};
	const onSave = async () => {
		setSaving(true);
		try {
			await onAssign(user.id, selected);
			setOpen(false);
		} finally {
			setSaving(false);
		}
	};
	const onCancel = () => {
		setSelected(user.vehicleIds);
		setOpen(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-6 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-medium text-foreground",
						children: user.email
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate text-xs text-muted-foreground",
						children: [
							user.name ?? "—",
							" · ",
							user.role,
							" · ",
							status
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: ["Vehicles: ", user.vehicleIds.length]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					isViewer && status === "pending" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => onSetStatus(user.id, "active"),
						children: "Approve"
					}),
					isViewer && status === "pending" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => onSetStatus(user.id, "rejected"),
						children: "Reject"
					}),
					isViewer && status === "active" && (!open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => setOpen(true),
						children: "Assign vehicles"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: onCancel,
						disabled: saving,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: onSave,
						disabled: saving,
						children: saving ? "Saving…" : "Save"
					})] }))
				]
			})]
		}), open && isViewer && status === "active" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2",
			children: [vehicleOptions.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 rounded-md border border-border bg-background px-3 py-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: selected.includes(v.id),
					disabled: v.assigned && !selected.includes(v.id),
					onChange: () => toggle(v.id)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 truncate",
					children: v.label
				})]
			}, v.id)), vehicleOptions.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No vehicles available."
			})]
		})]
	});
}
var SplitComponent = UsersPage;
//#endregion
export { SplitComponent as component };
