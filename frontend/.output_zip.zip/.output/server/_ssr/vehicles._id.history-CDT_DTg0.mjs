import { r as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { r as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { D as ArrowLeft, d as Play, f as Pause, g as MapPin, l as Route, o as Timer, x as Gauge } from "../_libs/lucide-react.mjs";
import { n as EmptyState, o as LoadingState, r as ErrorState } from "./spinner-muDgHEuQ.mjs";
import { n as DEFAULT_CENTER, r as MAP_STYLE } from "./client-DUvhSboa.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as useVehicle, n as fetchVehicleHistory, r as fetchVehicleHistorySummary } from "./useVehicles-Bwt4z13w.mjs";
import { i as formatDuration, n as formatDateTime, o as formatSpeed, r as formatDistance } from "./format-Dbvgyw5I.mjs";
import { t as require_maplibre_gl } from "../_libs/maplibre-gl.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route$1 } from "./vehicles._id.history-DrB1Fgox.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicles._id.history-CDT_DTg0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_maplibre_gl = /* @__PURE__ */ __toESM(require_maplibre_gl());
function useVehicleHistory(id, start, end, options) {
	return useQuery({
		queryKey: [
			"vehicle-history",
			id,
			start,
			end,
			options?.downsample
		],
		queryFn: () => fetchVehicleHistory(id, start, end, options),
		enabled: Boolean(id && start && end)
	});
}
function useVehicleHistorySummary(id, start, end) {
	return useQuery({
		queryKey: [
			"vehicle-history-summary",
			id,
			start,
			end
		],
		queryFn: () => fetchVehicleHistorySummary(id, start, end),
		enabled: Boolean(id && start && end)
	});
}
function pointsToLineString(points) {
	return {
		type: "Feature",
		properties: {},
		geometry: {
			type: "LineString",
			coordinates: points.map((p) => [p.longitude, p.latitude])
		}
	};
}
function boundsOf(points) {
	if (points.length === 0) return null;
	let minLng = Infinity, minLat = Infinity, maxLng = -Infinity, maxLat = -Infinity;
	for (const p of points) {
		minLng = Math.min(minLng, p.longitude);
		maxLng = Math.max(maxLng, p.longitude);
		minLat = Math.min(minLat, p.latitude);
		maxLat = Math.max(maxLat, p.latitude);
	}
	return [[minLng, minLat], [maxLng, maxLat]];
}
function RouteMap({ points, marker, className }) {
	const containerRef = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const playMarkerRef = (0, import_react.useRef)(null);
	const loadedRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!containerRef.current || mapRef.current) return;
		const map = new import_maplibre_gl.default.Map({
			container: containerRef.current,
			style: MAP_STYLE,
			center: DEFAULT_CENTER,
			zoom: 10
		});
		map.addControl(new import_maplibre_gl.default.NavigationControl(), "top-right");
		map.on("load", () => {
			loadedRef.current = true;
			map.addSource("route", {
				type: "geojson",
				data: {
					type: "FeatureCollection",
					features: []
				}
			});
			map.addLayer({
				id: "route-line",
				type: "line",
				source: "route",
				layout: {
					"line-join": "round",
					"line-cap": "round"
				},
				paint: {
					"line-color": "#10b981",
					"line-width": 4
				}
			});
			drawRoute();
		});
		mapRef.current = map;
		return () => {
			map.remove();
			mapRef.current = null;
			loadedRef.current = false;
		};
	}, []);
	const drawRoute = () => {
		const map = mapRef.current;
		if (!map || !loadedRef.current) return;
		const src = map.getSource("route");
		if (!src) return;
		src.setData({
			type: "FeatureCollection",
			features: points.length ? [pointsToLineString(points)] : []
		});
		const b = boundsOf(points);
		if (b) map.fitBounds(b, {
			padding: 60,
			maxZoom: 15,
			duration: 600
		});
	};
	(0, import_react.useEffect)(() => {
		drawRoute();
	}, [points]);
	(0, import_react.useEffect)(() => {
		const map = mapRef.current;
		if (!map) return;
		if (!marker) {
			playMarkerRef.current?.remove();
			playMarkerRef.current = null;
			return;
		}
		const lngLat = [marker.longitude, marker.latitude];
		if (playMarkerRef.current) playMarkerRef.current.setLngLat(lngLat);
		else {
			const el = document.createElement("div");
			el.style.cssText = "width:18px;height:18px;border-radius:50%;background:#f59e0b;border:3px solid white;box-shadow:0 1px 4px rgba(0,0,0,.4)";
			playMarkerRef.current = new import_maplibre_gl.default.Marker({ element: el }).setLngLat(lngLat).addTo(map);
		}
	}, [marker]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: containerRef,
		className
	});
}
function toLocalInput(d) {
	const off = d.getTimezoneOffset();
	return (/* @__PURE__ */ new Date(d.getTime() - off * 6e4)).toISOString().slice(0, 16);
}
function startOfDay(d) {
	const x = new Date(d);
	x.setHours(0, 0, 0, 0);
	return x;
}
function endOfDay(d) {
	const x = new Date(d);
	x.setHours(23, 59, 59, 999);
	return x;
}
function presetRange(preset) {
	const now = /* @__PURE__ */ new Date();
	switch (preset) {
		case "24h": return {
			start: (/* @__PURE__ */ new Date(now.getTime() - 24 * 3600 * 1e3)).toISOString(),
			end: now.toISOString()
		};
		case "today": return {
			start: startOfDay(now).toISOString(),
			end: now.toISOString()
		};
		case "yesterday": {
			const y = new Date(now);
			y.setDate(y.getDate() - 1);
			return {
				start: startOfDay(y).toISOString(),
				end: endOfDay(y).toISOString()
			};
		}
		case "7d": return {
			start: (/* @__PURE__ */ new Date(now.getTime() - 168 * 3600 * 1e3)).toISOString(),
			end: now.toISOString()
		};
	}
}
function HistoryRangePicker({ startInput, endInput, onStartChange, onEndChange, onApply, onPreset }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-xl border border-border bg-card p-4 shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-medium text-muted-foreground",
						children: "Start"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "datetime-local",
						value: startInput,
						onChange: (e) => onStartChange(e.target.value),
						className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-medium text-muted-foreground",
						children: "End"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "datetime-local",
						value: endInput,
						onChange: (e) => onEndChange(e.target.value),
						className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onApply,
					className: "rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90",
					children: "Load Route"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: [
				{
					id: "24h",
					label: "Last 24h"
				},
				{
					id: "today",
					label: "Today"
				},
				{
					id: "yesterday",
					label: "Yesterday"
				},
				{
					id: "7d",
					label: "Last 7 days"
				}
			].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onPreset(p.id),
				className: "rounded-full border border-border bg-background px-3 py-1 text-xs font-medium text-muted-foreground hover:bg-accent hover:text-accent-foreground",
				children: p.label
			}, p.id))
		})]
	});
}
function RouteAnalysisCards({ summary }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6",
		children: [
			{
				label: "Distance",
				value: formatDistance(summary.distanceKm),
				icon: Route
			},
			{
				label: "Duration",
				value: formatDuration(summary.durationSec),
				icon: Timer
			},
			{
				label: "Avg speed",
				value: formatSpeed(summary.avgSpeedKmh),
				icon: Gauge
			},
			{
				label: "Max speed",
				value: formatSpeed(summary.maxSpeedKmh),
				icon: Gauge
			},
			{
				label: "Moving",
				value: formatDuration(summary.movingSec),
				icon: Timer
			},
			{
				label: "Stops",
				value: String(summary.stopCount),
				icon: MapPin
			}
		].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-border bg-card p-4 shadow-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted-foreground",
					children: c.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(c.icon, { className: "h-4 w-4 text-muted-foreground" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-lg font-semibold",
				children: c.value
			})]
		}, c.label))
	});
}
function TruncatedBanner({ totalPointCount }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-800",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: "Sampled route shown."
			}),
			" ",
			totalPointCount != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [totalPointCount.toLocaleString(), " points in range — map uses a subset."] }),
			" ",
			"Narrow the date range for full detail."
		]
	});
}
function IdleNote() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "flex items-center gap-1 text-xs text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "h-3.5 w-3.5" }), "Idle time: included in duration stats"]
	});
}
function TripList({ trips, selectedIndex, onSelect }) {
	if (trips.length <= 1) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-b border-border px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "text-sm font-semibold",
				children: [
					"Trips (",
					trips.length,
					")"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Gaps over 30 minutes start a new trip."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "max-h-48 divide-y divide-border overflow-auto lg:max-h-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onSelect(null),
				className: cn("flex w-full flex-col gap-0.5 px-4 py-3 text-left text-sm hover:bg-accent/50", selectedIndex === null && "bg-accent"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: "All trips"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Full selected range"
				})]
			}) }), trips.map((trip, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onSelect(i),
				className: cn("flex w-full flex-col gap-0.5 px-4 py-3 text-left text-sm hover:bg-accent/50", selectedIndex === i && "bg-accent"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-medium",
						children: ["Trip ", i + 1]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground",
						children: [
							formatDateTime(trip.start),
							" → ",
							formatDateTime(trip.end)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground",
						children: [
							formatDistance(trip.distanceKm),
							" · ",
							formatDuration(trip.durationSec)
						]
					})
				]
			}) }, `${trip.start}-${trip.end}`))]
		})]
	});
}
var EARTH_RADIUS_KM = 6371;
function haversineKm(lat1, lng1, lat2, lng2) {
	const toRad = (d) => d * Math.PI / 180;
	const dLat = toRad(lat2 - lat1);
	const dLng = toRad(lng2 - lng1);
	const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
	return 2 * EARTH_RADIUS_KM * Math.asin(Math.sqrt(a));
}
function segmentTrips(points, gapMinutes = 30) {
	if (points.length === 0) return [];
	const gapMs = gapMinutes * 60 * 1e3;
	const trips = [[points[0]]];
	for (let i = 1; i < points.length; i++) {
		const prev = new Date(points[i - 1].timestamp).getTime();
		if (new Date(points[i].timestamp).getTime() - prev > gapMs) trips.push([points[i]]);
		else trips[trips.length - 1].push(points[i]);
	}
	return trips;
}
function distanceOfPoints(points) {
	let km = 0;
	for (let i = 1; i < points.length; i++) km += haversineKm(points[i - 1].latitude, points[i - 1].longitude, points[i].latitude, points[i].longitude);
	return km;
}
function isIdle(speed) {
	return speed == null || speed < 5;
}
function countStops(points) {
	if (points.length < 2) return 0;
	const stopMs = 300 * 1e3;
	let stops = 0;
	let idleStart = null;
	for (let i = 1; i < points.length; i++) {
		const t = new Date(points[i].timestamp).getTime();
		if (isIdle(points[i].speed)) {
			if (idleStart == null) idleStart = new Date(points[i - 1].timestamp).getTime();
		} else if (idleStart != null) {
			if (t - idleStart >= stopMs) stops++;
			idleStart = null;
		}
	}
	if (idleStart != null) {
		if (new Date(points[points.length - 1].timestamp).getTime() - idleStart >= stopMs) stops++;
	}
	return stops;
}
function movingIdleSec(points) {
	let movingSec = 0;
	let idleSec = 0;
	for (let i = 1; i < points.length; i++) {
		const dt = (new Date(points[i].timestamp).getTime() - new Date(points[i - 1].timestamp).getTime()) / 1e3;
		if (dt <= 0) continue;
		if (isIdle(points[i].speed) && isIdle(points[i - 1].speed)) idleSec += dt;
		else movingSec += dt;
	}
	return {
		movingSec,
		idleSec
	};
}
function computeRouteStats(points) {
	if (points.length === 0) return {
		pointCount: 0,
		firstTimestamp: null,
		lastTimestamp: null,
		distanceKm: 0,
		durationSec: 0,
		avgSpeedKmh: null,
		maxSpeedKmh: null,
		movingSec: 0,
		idleSec: 0,
		stopCount: 0,
		tripCount: 0,
		trips: []
	};
	const trips = segmentTrips(points);
	const first = points[0].timestamp;
	const last = points[points.length - 1].timestamp;
	const durationSec = Math.max(0, (new Date(last).getTime() - new Date(first).getTime()) / 1e3);
	const distanceKm = distanceOfPoints(points);
	const speeds = points.map((p) => p.speed).filter((s) => s != null && !Number.isNaN(s));
	const maxSpeedKmh = speeds.length ? Math.max(...speeds) : null;
	const avgSpeedKmh = durationSec > 0 ? distanceKm / durationSec * 3600 : null;
	const { movingSec, idleSec } = movingIdleSec(points);
	return {
		pointCount: points.length,
		firstTimestamp: first,
		lastTimestamp: last,
		distanceKm,
		durationSec,
		avgSpeedKmh,
		maxSpeedKmh,
		movingSec,
		idleSec,
		stopCount: countStops(points),
		tripCount: trips.length,
		trips: trips.map((trip) => {
			const tripFirst = trip[0].timestamp;
			const tripLast = trip[trip.length - 1].timestamp;
			return {
				start: tripFirst,
				end: tripLast,
				distanceKm: distanceOfPoints(trip),
				durationSec: Math.max(0, (new Date(tripLast).getTime() - new Date(tripFirst).getTime()) / 1e3)
			};
		})
	};
}
function filterPointsByTrip(points, trip) {
	const startMs = new Date(trip.start).getTime();
	const endMs = new Date(trip.end).getTime();
	return points.filter((p) => {
		const t = new Date(p.timestamp).getTime();
		return t >= startMs && t <= endMs;
	});
}
function RouteHistoryPage({ id }) {
	const { data: vehicle } = useVehicle(id);
	const now = (0, import_react.useMemo)(() => /* @__PURE__ */ new Date(), []);
	const [startInput, setStartInput] = (0, import_react.useState)(toLocalInput((0, import_react.useMemo)(() => /* @__PURE__ */ new Date(Date.now() - 24 * 3600 * 1e3), [])));
	const [endInput, setEndInput] = (0, import_react.useState)(toLocalInput(now));
	const [range, setRange] = (0, import_react.useState)(null);
	const [selectedTripIndex, setSelectedTripIndex] = (0, import_react.useState)(null);
	const historyQuery = useVehicleHistory(id, range?.start ?? null, range?.end ?? null, { downsample: 5 });
	const summaryQuery = useVehicleHistorySummary(id, range?.start ?? null, range?.end ?? null);
	const allPoints = historyQuery.data?.points ?? [];
	const summary = summaryQuery.data;
	const activeTrip = summary && selectedTripIndex != null ? summary.trips[selectedTripIndex] : null;
	const displayPoints = (0, import_react.useMemo)(() => {
		if (!activeTrip) return allPoints;
		return filterPointsByTrip(allPoints, activeTrip);
	}, [allPoints, activeTrip]);
	const displaySummary = (0, import_react.useMemo)(() => {
		if (!summary) return null;
		if (!activeTrip) return summary;
		const stats = computeRouteStats(displayPoints);
		return {
			vehicleId: summary.vehicleId,
			start: activeTrip.start,
			end: activeTrip.end,
			...stats
		};
	}, [
		summary,
		activeTrip,
		displayPoints
	]);
	const [idx, setIdx] = (0, import_react.useState)(0);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const timerRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setIdx(0);
		setPlaying(false);
		setSelectedTripIndex(null);
	}, [historyQuery.data]);
	(0, import_react.useEffect)(() => {
		setIdx(0);
		setPlaying(false);
	}, [selectedTripIndex, displayPoints.length]);
	(0, import_react.useEffect)(() => {
		if (!playing) {
			if (timerRef.current) clearInterval(timerRef.current);
			return;
		}
		timerRef.current = setInterval(() => {
			setIdx((i) => {
				if (i >= displayPoints.length - 1) {
					setPlaying(false);
					return i;
				}
				return i + 1;
			});
		}, 400);
		return () => {
			if (timerRef.current) clearInterval(timerRef.current);
		};
	}, [playing, displayPoints.length]);
	const apply = () => {
		setRange({
			start: new Date(startInput).toISOString(),
			end: new Date(endInput).toISOString()
		});
	};
	const applyPreset = (preset) => {
		const r = presetRange(preset);
		setStartInput(toLocalInput(new Date(r.start)));
		setEndInput(toLocalInput(new Date(r.end)));
		setRange(r);
	};
	const current = displayPoints[idx];
	const loading = Boolean(range) && (historyQuery.isLoading || summaryQuery.isLoading);
	const isError = historyQuery.isError || summaryQuery.isError;
	const error = historyQuery.error ?? summaryQuery.error;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl space-y-5 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/vehicles/$id",
				params: { id },
				className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back to vehicle"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold tracking-tight",
				children: "History & Analysis"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					vehicle?.vehicleName ?? "Vehicle",
					" · ",
					vehicle?.vehicleNumber ?? ""
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryRangePicker, {
				startInput,
				endInput,
				onStartChange: setStartInput,
				onEndChange: setEndInput,
				onApply: apply,
				onPreset: applyPreset
			}),
			!range ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "Select a time range",
				description: "Choose dates or use a preset, then load the route."
			}) : loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Loading history…" }) : isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
				message: error?.message,
				onRetry: () => {
					historyQuery.refetch();
					summaryQuery.refetch();
				}
			}) : allPoints.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "No history found",
				description: "There is no telemetry for this vehicle in the selected range."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					displaySummary && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RouteAnalysisCards, { summary: displaySummary }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleNote, {}),
					historyQuery.data?.truncated && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TruncatedBanner, { totalPointCount: historyQuery.data.totalPointCount }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 gap-4 lg:grid-cols-4",
						children: [summary && summary.tripCount > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:col-span-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TripList, {
								trips: summary.trips,
								selectedIndex: selectedTripIndex,
								onSelect: setSelectedTripIndex
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: summary && summary.tripCount > 1 ? "overflow-hidden rounded-xl border border-border bg-card shadow-sm lg:col-span-3" : "overflow-hidden rounded-xl border border-border bg-card shadow-sm lg:col-span-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RouteMap, {
								points: displayPoints,
								marker: current ?? null,
								className: "h-[420px] w-full"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-3 border-t border-border px-4 py-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setPlaying((p) => !p),
										className: "flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground hover:bg-primary/90",
										children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "range",
										min: 0,
										max: Math.max(0, displayPoints.length - 1),
										value: idx,
										onChange: (e) => setIdx(Number(e.target.value)),
										className: "flex-1 accent-emerald-500"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "min-w-[180px] text-right text-xs text-muted-foreground",
										children: current && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											formatDateTime(current.timestamp),
											" ·",
											" ",
											formatSpeed(current.speed)
										] })
									})
								]
							})]
						})]
					})
				]
			})
		]
	});
}
function HistoryRoute() {
	const { id } = Route$1.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RouteHistoryPage, { id });
}
//#endregion
export { HistoryRoute as component };
