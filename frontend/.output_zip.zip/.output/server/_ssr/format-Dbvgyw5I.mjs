//#region node_modules/.nitro/vite/services/ssr/assets/format-Dbvgyw5I.js
var COMPASS = [
	"N",
	"NNE",
	"NE",
	"ENE",
	"E",
	"ESE",
	"SE",
	"SSE",
	"S",
	"SSW",
	"SW",
	"WSW",
	"W",
	"WNW",
	"NW",
	"NNW"
];
function compass(heading) {
	if (heading == null || Number.isNaN(heading)) return "—";
	return COMPASS[Math.round((heading % 360 + 360) % 360 / 22.5) % 16];
}
function formatHeading(heading) {
	if (heading == null || Number.isNaN(heading)) return "—";
	return `${Math.round(heading)}° ${compass(heading)}`;
}
function formatSpeed(speed) {
	if (speed == null || Number.isNaN(speed)) return "—";
	return `${Math.round(speed)} km/h`;
}
function formatCoord(lat, lng) {
	if (lat == null || lng == null) return "—";
	return `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
}
function relativeTime(iso) {
	if (!iso) return "—";
	const then = new Date(iso).getTime();
	if (Number.isNaN(then)) return "—";
	const diff = Math.round((Date.now() - then) / 1e3);
	if (diff < 5) return "just now";
	if (diff < 60) return `${diff}s ago`;
	if (diff < 3600) return `${Math.floor(diff / 60)} min ago`;
	if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
	return `${Math.floor(diff / 86400)}d ago`;
}
function formatDateTime(iso) {
	if (!iso) return "—";
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return "—";
	return d.toLocaleString();
}
function formatDistance(km) {
	if (km == null || Number.isNaN(km)) return "—";
	if (km < 1) return `${Math.round(km * 1e3)} m`;
	return `${km.toFixed(1)} km`;
}
function formatDuration(sec) {
	if (sec == null || Number.isNaN(sec)) return "—";
	const s = Math.round(sec);
	if (s < 60) return `${s}s`;
	const m = Math.floor(s / 60);
	if (m < 60) return `${m}m ${s % 60}s`;
	return `${Math.floor(m / 60)}h ${m % 60}m`;
}
//#endregion
export { formatHeading as a, formatDuration as i, formatDateTime as n, formatSpeed as o, formatDistance as r, relativeTime as s, formatCoord as t };
