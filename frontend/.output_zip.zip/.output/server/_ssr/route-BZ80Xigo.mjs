import { r as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { r as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as LogOut, a as Truck, h as Map, i as User, m as Menu, n as Wifi, r as WifiOff, t as X, y as LayoutDashboard } from "../_libs/lucide-react.mjs";
import { l as WsEventSchema, o as LoadingState, r as ErrorState } from "./spinner-muDgHEuQ.mjs";
import { c as getWsUrlWithToken, i as WS_URL, s as getAuthToken } from "./client-DUvhSboa.mjs";
import { n as useVehicleStore } from "./vehicleStore-CQijUHLr.mjs";
import { _ as useNavigate, f as Outlet, g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useAuth } from "./AuthContext-CIziQDdM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-BZ80Xigo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var baseItems = [
	{
		title: "Dashboard",
		to: "/",
		icon: LayoutDashboard,
		exact: true
	},
	{
		title: "Live Map",
		to: "/map",
		icon: Map,
		exact: false
	},
	{
		title: "Vehicles",
		to: "/vehicles",
		icon: Truck,
		exact: false
	},
	{
		title: "Profile",
		to: "/profile",
		icon: User,
		exact: false
	}
];
var adminItems = [{
	title: "Users",
	to: "/users",
	icon: User,
	exact: false
}];
function Sidebar({ open, onClose }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const { user } = useAuth();
	const items = user?.role === "admin" ? [...baseItems, ...adminItems] : baseItems;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-30 bg-black/30 md:hidden",
		onClick: onClose
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: cn("fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-transform md:static md:translate-x-0", open ? "translate-x-0" : "-translate-x-full"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-16 items-center justify-between px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex h-8 w-8 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "h-5 w-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-lg font-semibold tracking-tight text-sidebar-foreground",
						children: "Fleet Tracker"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "rounded-md p-1 text-muted-foreground hover:text-foreground md:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex-1 space-y-1 px-3 py-4",
				children: items.map((item) => {
					const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						onClick: onClose,
						className: cn("flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors", active ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "h-5 w-5" }), item.title]
					}, item.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-5 py-4 text-xs text-muted-foreground",
				children: "Realtime GPS fleet monitoring"
			})
		]
	})] });
}
function Header({ onMenu }) {
	const connected = useVehicleStore((s) => s.wsConnected);
	const { user, organization, logout } = useAuth();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex h-16 items-center gap-3 border-b border-border bg-background px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onMenu,
				className: "rounded-md p-2 text-muted-foreground hover:bg-accent md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [organization && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-sm font-semibold text-foreground",
					children: organization.name
				}), user && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs text-muted-foreground",
					children: user.email
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium", connected ? "bg-primary/10 text-primary" : "bg-amber-500/15 text-amber-700"),
				children: [connected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WifiOff, { className: "h-3.5 w-3.5" }), connected ? "Live" : "Reconnecting"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => logout(),
				className: "inline-flex items-center gap-1.5 rounded-md px-2.5 py-2 text-sm text-muted-foreground hover:bg-accent hover:text-foreground",
				"aria-label": "Log out",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden sm:inline",
					children: "Log out"
				})]
			})
		]
	});
}
/**
* Single WebSocket connection with exponential-backoff reconnect.
* Updates the Zustand store on each event — never refetches the full list.
*/
function useVehicleWebSocket() {
	const updatePosition = useVehicleStore((s) => s.updatePosition);
	const updateStatus = useVehicleStore((s) => s.updateStatus);
	const setConnected = useVehicleStore((s) => s.setConnected);
	const wsRef = (0, import_react.useRef)(null);
	const attemptRef = (0, import_react.useRef)(0);
	const timerRef = (0, import_react.useRef)(null);
	const closedRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		closedRef.current = false;
		const connect = () => {
			if (closedRef.current) return;
			const token = getAuthToken();
			if (!token) {
				setConnected(false);
				return;
			}
			let ws;
			try {
				ws = new WebSocket(getWsUrlWithToken(WS_URL, token));
			} catch {
				scheduleReconnect();
				return;
			}
			wsRef.current = ws;
			ws.onopen = () => {
				attemptRef.current = 0;
				setConnected(true);
			};
			ws.onmessage = (msg) => {
				try {
					const parsed = WsEventSchema.safeParse(JSON.parse(msg.data));
					if (!parsed.success) return;
					if (parsed.data.type === "vehicle_location_update") updatePosition(parsed.data);
					else updateStatus(parsed.data);
				} catch {}
			};
			ws.onclose = () => {
				setConnected(false);
				scheduleReconnect();
			};
			ws.onerror = () => {
				ws.close();
			};
		};
		const scheduleReconnect = () => {
			if (closedRef.current) return;
			const delay = Math.min(1e3 * 2 ** attemptRef.current, 3e4);
			attemptRef.current += 1;
			timerRef.current = setTimeout(connect, delay);
		};
		connect();
		return () => {
			closedRef.current = true;
			if (timerRef.current) clearTimeout(timerRef.current);
			wsRef.current?.close();
			wsRef.current = null;
		};
	}, [
		updatePosition,
		updateStatus,
		setConnected
	]);
}
function AppLayout({ children }) {
	const [sidebarOpen, setSidebarOpen] = (0, import_react.useState)(false);
	useVehicleWebSocket();
	(0, import_react.useEffect)(() => {
		document.documentElement.classList.remove("dark");
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-screen w-full overflow-hidden bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {
			open: sidebarOpen,
			onClose: () => setSidebarOpen(false)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-1 flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, { onMenu: () => setSidebarOpen(true) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "min-h-0 flex-1 overflow-auto bg-muted/20",
				children
			})]
		})]
	});
}
function AuthenticatedLayout() {
	const navigate = useNavigate();
	const redirectTarget = useRouterState({ select: (s) => s.location.href });
	const { isLoading, isAuthenticated, restoreError, retryRestore } = useAuth();
	(0, import_react.useEffect)(() => {
		if (isLoading) return;
		if (!getAuthToken()) navigate({
			to: "/login",
			search: { redirect: redirectTarget }
		});
	}, [
		isLoading,
		navigate,
		redirectTarget
	]);
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Restoring session…" });
	if (!getAuthToken()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Redirecting to sign in…" });
	if (restoreError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
		message: restoreError,
		onRetry: () => void retryRestore()
	});
	if (!isAuthenticated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Restoring session…" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
}
//#endregion
export { AuthenticatedLayout as component };
