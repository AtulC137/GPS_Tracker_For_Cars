import { r as __toESM } from "../_runtime.mjs";
import { r as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as DEFAULT_CENTER, r as MAP_STYLE } from "./client-DUvhSboa.mjs";
import { a as formatHeading, o as formatSpeed, s as relativeTime } from "./format-Dbvgyw5I.mjs";
import { t as require_maplibre_gl } from "../_libs/maplibre-gl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/FleetMap-Wwx9Unqf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_maplibre_gl = /* @__PURE__ */ __toESM(require_maplibre_gl());
function markerInner(v) {
	const online = v.live?.status === "online";
	return `<div style="transform:rotate(${v.live?.heading ?? 0}deg);width:0;height:0;border-left:9px solid transparent;border-right:9px solid transparent;border-bottom:20px solid ${online ? "#22c55e" : "#94a3b8"};filter:drop-shadow(0 1px 2px rgba(0,0,0,.4));"></div>`;
}
function markerEl(v) {
	const el = document.createElement("div");
	el.className = "fleet-marker";
	el.style.cssText = "width:30px;height:30px;display:flex;align-items:center;justify-content:center;cursor:pointer;";
	el.innerHTML = markerInner(v);
	return el;
}
function popupHtml(v) {
	return `<div style="font-size:12px;min-width:150px">
    <div style="font-weight:600;margin-bottom:4px">${v.vehicleName}</div>
    <div style="color:#64748b">${v.vehicleNumber}</div>
    <div style="margin-top:6px">Speed: ${formatSpeed(v.live?.speed)}</div>
    <div>Heading: ${formatHeading(v.live?.heading)}</div>
    <div>Seen: ${relativeTime(v.live?.lastSeenAt)}</div>
  </div>`;
}
function FleetMap({ vehicles, focusId, className }) {
	const containerRef = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const markersRef = (0, import_react.useRef)({});
	const loadedRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!containerRef.current || mapRef.current) return;
		const map = new import_maplibre_gl.default.Map({
			container: containerRef.current,
			style: MAP_STYLE,
			center: DEFAULT_CENTER,
			zoom: 10
		});
		map.addControl(new import_maplibre_gl.default.NavigationControl(), "top-right");
		map.on("load", () => {
			loadedRef.current = true;
		});
		mapRef.current = map;
		return () => {
			map.remove();
			mapRef.current = null;
			markersRef.current = {};
			loadedRef.current = false;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const map = mapRef.current;
		if (!map) return;
		const seen = /* @__PURE__ */ new Set();
		for (const v of vehicles) {
			if (!v.live) continue;
			seen.add(v.id);
			const lngLat = [v.live.longitude, v.live.latitude];
			const existing = markersRef.current[v.id];
			if (existing) {
				existing.setLngLat(lngLat);
				existing.getElement().innerHTML = markerInner(v);
			} else {
				const marker = new import_maplibre_gl.default.Marker({ element: markerEl(v) }).setLngLat(lngLat).setPopup(new import_maplibre_gl.default.Popup({ offset: 16 }).setHTML(popupHtml(v))).addTo(map);
				markersRef.current[v.id] = marker;
			}
		}
		for (const [id, marker] of Object.entries(markersRef.current)) if (!seen.has(id)) {
			marker.remove();
			delete markersRef.current[id];
		} else {
			const v = vehicles.find((x) => x.id === id);
			if (v) marker.getPopup()?.setHTML(popupHtml(v));
		}
	}, [vehicles]);
	(0, import_react.useEffect)(() => {
		if (!focusId) return;
		const v = vehicles.find((x) => x.id === focusId);
		if (v?.live && mapRef.current) {
			mapRef.current.flyTo({
				center: [v.live.longitude, v.live.latitude],
				zoom: 14
			});
			markersRef.current[focusId]?.togglePopup();
		}
	}, [focusId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: containerRef,
		className
	});
}
//#endregion
export { FleetMap as t };
