import { t as cn } from "./utils-C_uf36nf.mjs";
import { r as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as literalType, c as stringType, i as enumType, l as unionType, n as booleanType, o as numberType, r as discriminatedUnionType, s as objectType, t as arrayType } from "../_libs/zod.mjs";
import { v as LoaderCircle } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/spinner-muDgHEuQ.js
var import_jsx_runtime = require_jsx_runtime();
var VehicleStatusSchema = enumType(["online", "offline"]);
var VehicleStateSchema = objectType({
	latitude: numberType(),
	longitude: numberType(),
	speed: numberType().optional().nullable(),
	heading: numberType().optional().nullable(),
	lastSeenAt: stringType(),
	status: VehicleStatusSchema
});
var VehicleSchema = objectType({
	id: stringType(),
	vehicleName: stringType(),
	vehicleNumber: stringType(),
	deviceId: stringType(),
	trackerType: enumType(["ais140", "owntracks_phone"]).optional(),
	createdAt: stringType().optional(),
	currentState: VehicleStateSchema.nullable().optional()
});
var LiveStateSchema = objectType({
	vehicleId: stringType(),
	latitude: numberType(),
	longitude: numberType(),
	speed: numberType().optional().nullable(),
	heading: numberType().optional().nullable(),
	lastSeenAt: stringType(),
	status: VehicleStatusSchema
});
var HistoryPointSchema = objectType({
	latitude: numberType(),
	longitude: numberType(),
	speed: numberType().optional().nullable(),
	heading: numberType().optional().nullable(),
	timestamp: stringType()
});
var HistorySchema = objectType({
	vehicleId: stringType(),
	start: stringType().optional(),
	end: stringType().optional(),
	points: arrayType(HistoryPointSchema),
	truncated: booleanType().optional(),
	totalPointCount: numberType().optional()
});
var TripSummarySchema = objectType({
	start: stringType(),
	end: stringType(),
	distanceKm: numberType(),
	durationSec: numberType()
});
var RouteSummarySchema = objectType({
	vehicleId: stringType(),
	start: stringType(),
	end: stringType(),
	pointCount: numberType(),
	firstTimestamp: stringType().nullable(),
	lastTimestamp: stringType().nullable(),
	distanceKm: numberType(),
	durationSec: numberType(),
	avgSpeedKmh: numberType().nullable(),
	maxSpeedKmh: numberType().nullable(),
	movingSec: numberType(),
	idleSec: numberType(),
	stopCount: numberType(),
	tripCount: numberType(),
	trips: arrayType(TripSummarySchema)
});
var WsEventSchema = discriminatedUnionType("type", [objectType({
	type: literalType("vehicle_location_update"),
	vehicleId: stringType(),
	latitude: numberType(),
	longitude: numberType(),
	speed: numberType().optional().nullable(),
	heading: numberType().optional().nullable(),
	lastSeenAt: stringType()
}), objectType({
	type: literalType("vehicle_status_update"),
	vehicleId: stringType(),
	status: VehicleStatusSchema
})]);
var CreateVehicleResponseSchema = objectType({
	vehicle: VehicleSchema,
	setup: unionType([objectType({
		trackerType: literalType("ais140"),
		imei: stringType(),
		vehicleNumber: stringType(),
		deviceId: stringType(),
		tcpHost: stringType(),
		tcpPort: numberType(),
		protocol: literalType("TCP"),
		note: stringType()
	}), objectType({
		trackerType: literalType("owntracks_phone"),
		tid: stringType(),
		vehicleNumber: stringType(),
		deviceId: stringType(),
		http: objectType({
			mode: stringType(),
			url: stringType(),
			authRequired: booleanType(),
			authHint: stringType().optional()
		}),
		mqtt: objectType({
			mode: stringType(),
			host: stringType(),
			port: numberType(),
			topic: stringType(),
			tailscaleNote: stringType()
		}),
		note: stringType()
	})])
});
function Spinner({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: cn("h-5 w-5 animate-spin", className) });
}
function LoadingState({ label = "Loading…" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center gap-3 py-16 text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, { className: "h-6 w-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm",
			children: label
		})]
	});
}
function EmptyState({ title, description }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center gap-2 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-medium text-foreground",
			children: title
		}), description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-sm text-sm text-muted-foreground",
			children: description
		})]
	});
}
function ErrorState({ message, onRetry }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center gap-3 py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-destructive",
				children: "Something went wrong"
			}),
			message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-xs text-muted-foreground",
				children: message
			}),
			onRetry && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onRetry,
				className: "mt-1 rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground hover:bg-primary/90",
				children: "Retry"
			})
		]
	});
}
//#endregion
export { LiveStateSchema as a, VehicleSchema as c, HistorySchema as i, WsEventSchema as l, EmptyState as n, LoadingState as o, ErrorState as r, RouteSummarySchema as s, CreateVehicleResponseSchema as t };
