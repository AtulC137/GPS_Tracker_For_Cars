import { r as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { r as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as Copy, E as ArrowUpDown, T as Car, c as Search, g as MapPin, p as Navigation, s as Smartphone, t as X, u as Plus, x as Gauge } from "../_libs/lucide-react.mjs";
import { n as EmptyState, o as LoadingState, r as ErrorState } from "./spinner-muDgHEuQ.mjs";
import { t as ApiError } from "./client-DUvhSboa.mjs";
import { i as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { i as updateVehicle, s as useVehicles, t as createVehicle } from "./useVehicles-Bwt4z13w.mjs";
import { n as useVehicleStore } from "./vehicleStore-CQijUHLr.mjs";
import { t as useMergedVehicles } from "./useMergedVehicles-kPiaX86R.mjs";
import { a as formatHeading, o as formatSpeed, s as relativeTime } from "./format-Dbvgyw5I.mjs";
import { t as VehicleStatusBadge } from "./VehicleStatusBadge-B7pv-ZBP.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Portal, i as Overlay, n as Content, o as Root, r as Description, s as Title, t as Close } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { r as useAuth } from "./AuthContext-CIziQDdM.mjs";
import { n as Input, r as Label, t as Button } from "./label-BxvS4Y9r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicles.index-CyjqiFU4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VehicleCard({ vehicle, canEdit }) {
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card p-4 shadow-sm transition-colors hover:border-primary/40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => navigate({
				to: "/vehicles/$id",
				params: { id: vehicle.id }
			}),
			className: "block w-full text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: vehicle.vehicleName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: vehicle.vehicleNumber
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleStatusBadge, { status: vehicle.live?.status })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "h-3.5 w-3.5" }),
							" ",
							formatSpeed(vehicle.live?.speed)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, { className: "h-3.5 w-3.5" }),
							" ",
							formatHeading(vehicle.live?.heading)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "col-span-2 flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-3.5 w-3.5" }),
							" ",
							relativeTime(vehicle.live?.lastSeenAt)
						]
					})
				]
			})]
		}), canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 flex justify-end",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/vehicles/$id",
				params: { id: vehicle.id },
				className: "text-sm font-medium text-primary hover:underline",
				children: "Edit details"
			})
		})]
	});
}
function VehicleTable({ vehicles, canEdit }) {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const [query, setQuery] = (0, import_react.useState)("");
	const [sort, setSort] = (0, import_react.useState)("vehicleName");
	const [asc, setAsc] = (0, import_react.useState)(true);
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [vehicleName, setVehicleName] = (0, import_react.useState)("");
	const [vehicleNumber, setVehicleNumber] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [saveError, setSaveError] = (0, import_react.useState)(null);
	const filtered = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		const list = vehicles.filter((v) => !q || v.vehicleName.toLowerCase().includes(q) || v.vehicleNumber.toLowerCase().includes(q) || v.deviceId.toLowerCase().includes(q));
		const dir = asc ? 1 : -1;
		return [...list].sort((a, b) => {
			switch (sort) {
				case "speed": return ((a.live?.speed ?? 0) - (b.live?.speed ?? 0)) * dir;
				case "status": return (a.live?.status ?? "").localeCompare(b.live?.status ?? "") * dir;
				case "lastSeen": return (new Date(a.live?.lastSeenAt ?? 0).getTime() - new Date(b.live?.lastSeenAt ?? 0).getTime()) * dir;
				default: return a[sort].localeCompare(b[sort]) * dir;
			}
		});
	}, [
		vehicles,
		query,
		sort,
		asc
	]);
	const toggleSort = (key) => {
		if (sort === key) setAsc((v) => !v);
		else {
			setSort(key);
			setAsc(true);
		}
	};
	const headers = [
		{
			key: "vehicleName",
			label: "Vehicle"
		},
		{
			key: "vehicleNumber",
			label: "Number"
		},
		{
			key: "status",
			label: "Status"
		},
		{
			key: "speed",
			label: "Speed"
		},
		{
			key: "lastSeen",
			label: "Last Seen"
		}
	];
	const startEdit = (v) => {
		setSaveError(null);
		setEditingId(v.id);
		setVehicleName(v.vehicleName);
		setVehicleNumber(v.vehicleNumber);
	};
	const cancelEdit = () => {
		setSaveError(null);
		setEditingId(null);
		setVehicleName("");
		setVehicleNumber("");
	};
	const onSave = async (id) => {
		if (!canEdit || user?.role !== "admin") return;
		const name = vehicleName.trim();
		const number = vehicleNumber.trim();
		if (!name || !number) return;
		setSaving(true);
		setSaveError(null);
		try {
			await updateVehicle(id, {
				vehicleName: name,
				vehicleNumber: number
			});
			await Promise.all([queryClient.invalidateQueries({ queryKey: ["vehicles"] }), queryClient.invalidateQueries({ queryKey: ["vehicle", id] })]);
			cancelEdit();
		} catch (err) {
			setSaveError(err instanceof ApiError ? err.message : "Unable to save vehicle.");
		} finally {
			setSaving(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative max-w-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: query,
				onChange: (e) => setQuery(e.target.value),
				placeholder: "Search name, number or device…",
				className: "w-full rounded-lg border border-input bg-background py-2 pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-ring"
			})]
		}), filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "No vehicles found",
			description: "Try a different search term."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden overflow-hidden rounded-xl border border-border bg-card md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-muted/50 text-left text-xs uppercase text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							headers.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => toggleSort(h.key),
									className: "inline-flex items-center gap-1 hover:text-foreground",
									children: [h.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpDown, { className: "h-3 w-3" })]
								})
							}, h.key)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Type"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Device"
							}),
							canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Actions"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y divide-border",
						children: filtered.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							tabIndex: 0,
							onClick: () => navigate({
								to: "/vehicles/$id",
								params: { id: v.id }
							}),
							onKeyDown: (e) => {
								if (e.key === "Enter") navigate({
									to: "/vehicles/$id",
									params: { id: v.id }
								});
							},
							className: "cursor-pointer outline-none hover:bg-accent/50 focus:bg-accent/50",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium",
									children: editingId === v.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: vehicleName,
										onChange: (e) => setVehicleName(e.target.value),
										onClick: (e) => e.stopPropagation(),
										className: "h-8"
									}) : v.vehicleName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: editingId === v.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: vehicleNumber,
										onChange: (e) => setVehicleNumber(e.target.value),
										onClick: (e) => e.stopPropagation(),
										className: "h-8"
									}) : v.vehicleNumber
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleStatusBadge, { status: v.live?.status })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: formatSpeed(v.live?.speed)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: relativeTime(v.live?.lastSeenAt)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: v.trackerType === "owntracks_phone" ? "Phone" : "AIS-140"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: v.deviceId
								}),
								canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									onClick: (e) => e.stopPropagation(),
									children: editingId === v.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-end gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "outline",
											size: "sm",
											onClick: cancelEdit,
											disabled: saving,
											children: "Cancel"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											size: "sm",
											onClick: () => onSave(v.id),
											disabled: saving || !vehicleName.trim() || !vehicleNumber.trim(),
											children: saving ? "Saving…" : "Save"
										})]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center justify-end",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "outline",
											size: "sm",
											onClick: () => startEdit(v),
											children: "Quick edit"
										})
									})
								})
							]
						}, v.id))
					})]
				})
			}),
			canEdit && saveError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive",
				children: saveError
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 gap-3 sm:grid-cols-2 md:hidden",
				children: filtered.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCard, {
					vehicle: v,
					canEdit
				}, v.id))
			})
		] })]
	});
}
var Dialog = Root;
var DialogPortal = Portal;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = Overlay.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Content, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Close, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = Content.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = Title.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = Description.displayName;
function CopyRow({ label, value }) {
	const copy = async () => {
		await navigator.clipboard.writeText(value);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-2 rounded-lg border border-border bg-muted/30 px-3 py-2 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-muted-foreground",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "break-all font-mono text-foreground",
				children: value
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => void copy(),
			className: "shrink-0 rounded p-1 text-muted-foreground hover:bg-accent hover:text-foreground",
			"aria-label": `Copy ${label}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" })
		})]
	});
}
function SetupInstructions({ setup }) {
	if (setup.trackerType === "ais140") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: setup.note
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
				label: "IMEI",
				value: setup.imei
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
				label: "VRN / plate",
				value: setup.vehicleNumber
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
				label: "Device ID",
				value: setup.deviceId
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
				label: "Server host",
				value: setup.tcpHost
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
				label: "TCP port",
				value: String(setup.tcpPort)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					"Protocol: ",
					setup.protocol,
					". Configure these on the AIS-140 VLT per MH SOP before the vehicle sends its first packet."
				]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: setup.note
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
				label: "Tracker ID (tid)",
				value: setup.tid
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
				label: "Device ID",
				value: setup.deviceId
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "text-sm font-semibold",
						children: "HTTP mode (ngrok)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
						label: "URL",
						value: setup.http.url
					}),
					setup.http.authRequired && setup.http.authHint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: setup.http.authHint
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "text-sm font-semibold",
						children: "MQTT + Tailscale"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
						label: "Broker host",
						value: setup.mqtt.host
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
						label: "Port",
						value: String(setup.mqtt.port)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
						label: "Topic",
						value: setup.mqtt.topic
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: setup.mqtt.tailscaleNote
					})
				]
			})
		]
	});
}
function AddTrackerDialog({ open, onOpenChange, onCreated }) {
	const [step, setStep] = (0, import_react.useState)("choose");
	const [choice, setChoice] = (0, import_react.useState)(null);
	const [vehicleName, setVehicleName] = (0, import_react.useState)("");
	const [vehicleNumber, setVehicleNumber] = (0, import_react.useState)("");
	const [imei, setImei] = (0, import_react.useState)("");
	const [tid, setTid] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [setup, setSetup] = (0, import_react.useState)(null);
	const [createdVehicleId, setCreatedVehicleId] = (0, import_react.useState)(null);
	const reset = () => {
		setStep("choose");
		setChoice(null);
		setVehicleName("");
		setVehicleNumber("");
		setImei("");
		setTid("");
		setError(null);
		setSetup(null);
		setCreatedVehicleId(null);
	};
	const handleClose = (next) => {
		if (!next) reset();
		onOpenChange(next);
	};
	const submit = async () => {
		if (!choice) return;
		setError(null);
		setSubmitting(true);
		const payload = choice === "ais140" ? {
			trackerType: "ais140",
			vehicleName,
			vehicleNumber,
			imei
		} : {
			trackerType: "owntracks_phone",
			vehicleName,
			vehicleNumber,
			tid
		};
		try {
			const result = await createVehicle(payload);
			setSetup(result.setup);
			setCreatedVehicleId(result.vehicle.id);
			setStep("setup");
			onCreated();
		} catch (err) {
			setError(err instanceof ApiError ? err.message : "Failed to add tracker");
		} finally {
			setSubmitting(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: handleClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[90vh] max-w-lg overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add tracker" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Register a device in your fleet, then configure the hardware or phone app." })] }),
				step === "choose" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setChoice("ais140");
							setStep("form");
						},
						className: "flex flex-col items-start gap-2 rounded-xl border border-border bg-card p-4 text-left transition-colors hover:border-primary hover:bg-accent/40",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Car, { className: "h-6 w-6 text-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: "AIS-140 VLT"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: "In-car hardware over TCP (MH SOP)"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setChoice("owntracks_phone");
							setStep("form");
						},
						className: "flex flex-col items-start gap-2 rounded-xl border border-border bg-card p-4 text-left transition-colors hover:border-primary hover:bg-accent/40",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "h-6 w-6 text-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: "OwnTracks phone"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: "HTTP (ngrok) or MQTT (Tailscale)"
							})
						]
					})]
				}),
				step === "form" && choice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-4",
					onSubmit: (e) => {
						e.preventDefault();
						submit();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-foreground",
							children: choice === "ais140" ? "AIS-140 vehicle" : "OwnTracks phone"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "vehicleName",
								children: "Vehicle name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "vehicleName",
								value: vehicleName,
								onChange: (e) => setVehicleName(e.target.value),
								placeholder: "My Car",
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "vehicleNumber",
								children: "Plate / VRN"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "vehicleNumber",
								value: vehicleNumber,
								onChange: (e) => setVehicleNumber(e.target.value),
								placeholder: "MH01AB1234",
								required: true
							})]
						}),
						choice === "ais140" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "imei",
								children: "IMEI (15 digits)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "imei",
								value: imei,
								onChange: (e) => setImei(e.target.value.replace(/\D/g, "").slice(0, 15)),
								placeholder: "888888888888999",
								pattern: "\\d{15}",
								required: true
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "tid",
								children: "Tracker ID (tid)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "tid",
								value: tid,
								onChange: (e) => setTid(e.target.value.replace(/[^A-Za-z0-9]/g, "").slice(0, 8)),
								placeholder: "AT",
								required: true
							})]
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: () => setStep("choose"),
								children: "Back"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								className: "flex-1",
								disabled: submitting,
								children: submitting ? "Adding…" : "Add tracker"
							})]
						})
					]
				}),
				step === "setup" && setup && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SetupInstructions, { setup }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [createdVehicleId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							size: "sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/vehicles/$id",
								params: { id: createdVehicleId },
								children: "View vehicle"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							onClick: () => {
								reset();
								onOpenChange(false);
							},
							children: "Done"
						})]
					})]
				})
			]
		})
	});
}
function AddTrackerButton({ onCreated, className }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		onClick: () => setOpen(true),
		className: cn(className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-2 h-4 w-4" }), "Add tracker"]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddTrackerDialog, {
		open,
		onOpenChange: setOpen,
		onCreated
	})] });
}
function VehiclesPage() {
	const { user } = useAuth();
	const { data, isLoading, isError, error, refetch } = useVehicles();
	const syncFromVehicles = useVehicleStore((s) => s.syncFromVehicles);
	const merged = useMergedVehicles(data);
	const [, setRefreshKey] = (0, import_react.useState)(0);
	const canEdit = user?.role === "admin";
	(0, import_react.useEffect)(() => {
		if (data) syncFromVehicles(data);
	}, [data, syncFromVehicles]);
	const handleCreated = () => {
		refetch();
		setRefreshKey((k) => k + 1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl space-y-6 p-4 sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold tracking-tight",
				children: "Vehicles"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					merged.length,
					" vehicle",
					merged.length === 1 ? "" : "s",
					" in fleet."
				]
			})] }), user?.role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddTrackerButton, {
				onCreated: handleCreated,
				className: "shrink-0"
			})]
		}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Loading vehicles…" }) : isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
			message: error?.message,
			onRetry: () => refetch()
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleTable, {
			vehicles: merged,
			canEdit
		})]
	});
}
var SplitComponent = VehiclesPage;
//#endregion
export { SplitComponent as component };
