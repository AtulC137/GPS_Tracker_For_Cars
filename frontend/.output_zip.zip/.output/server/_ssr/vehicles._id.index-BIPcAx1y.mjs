import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicles._id.index-BIPcAx1y.js
var $$splitComponentImporter = () => import("./vehicles._id.index-CY8dIapR.mjs");
var Route = createFileRoute("/_authenticated/vehicles/$id/")({
	head: () => ({ meta: [{ title: "Vehicle Details — Fleet Tracker" }, {
		name: "description",
		content: "Live location, speed, heading and status for a fleet vehicle."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
