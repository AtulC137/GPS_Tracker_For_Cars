import { r as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { r as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as Crosshair } from "../_libs/lucide-react.mjs";
import { o as LoadingState } from "./spinner-muDgHEuQ.mjs";
import { s as useVehicles } from "./useVehicles-Bwt4z13w.mjs";
import { n as useVehicleStore } from "./vehicleStore-CQijUHLr.mjs";
import { t as useMergedVehicles } from "./useMergedVehicles-kPiaX86R.mjs";
import { o as formatSpeed } from "./format-Dbvgyw5I.mjs";
import { t as VehicleStatusBadge } from "./VehicleStatusBadge-B7pv-ZBP.mjs";
import { t as FleetMap } from "./FleetMap-Wwx9Unqf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/map-DKn1x_W-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LiveMapPage() {
	const { data, isLoading } = useVehicles();
	const syncFromVehicles = useVehicleStore((s) => s.syncFromVehicles);
	const merged = useMergedVehicles(data);
	const [focusId, setFocusId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (data) syncFromVehicles(data);
	}, [data, syncFromVehicles]);
	const focus = (id) => {
		setFocusId(null);
		requestAnimationFrame(() => setFocusId(id));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col md:flex-row",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "order-2 flex w-full flex-col border-t border-border bg-card md:order-1 md:h-full md:w-72 md:border-r md:border-t-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b border-border px-4 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Vehicles"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-48 flex-1 overflow-auto md:max-h-none",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, {}) : merged.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => focus(v.id),
					className: cn("flex w-full items-center gap-2 border-b border-border px-4 py-3 text-left hover:bg-accent/50", focusId === v.id && "bg-accent"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "h-4 w-4 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-medium",
								children: v.vehicleName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-muted-foreground",
								children: formatSpeed(v.live?.speed)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleStatusBadge, { status: v.live?.status })
					]
				}, v.id))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "order-1 min-h-[300px] flex-1 md:order-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FleetMap, {
				vehicles: merged,
				focusId,
				className: "h-full w-full"
			})
		})]
	});
}
var SplitComponent = LiveMapPage;
//#endregion
export { SplitComponent as component };
