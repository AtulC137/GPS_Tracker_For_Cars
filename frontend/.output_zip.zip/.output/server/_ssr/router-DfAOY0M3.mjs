import { r as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { s as getAuthToken } from "./client-DUvhSboa.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { A as redirect, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as AuthProvider } from "./AuthContext-CIziQDdM.mjs";
import { t as Route$11 } from "./vehicles._id.index-BIPcAx1y.mjs";
import { t as Route$12 } from "./vehicles._id.history-DrB1Fgox.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DfAOY0M3.js
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-BPmujWbG.css";
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$10 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Fleet Tracker" },
			{
				name: "description",
				content: "Realtime GPS fleet tracking dashboard"
			},
			{
				property: "og:title",
				content: "Fleet Tracker"
			},
			{
				property: "og:description",
				content: "Realtime GPS fleet tracking dashboard"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			}
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$10.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) })
	});
}
var BASE_URL = "";
var Route$9 = createFileRoute("/sitemap.xml")({ server: { handlers: { GET: async () => {
	const xml = [
		`<?xml version="1.0" encoding="UTF-8"?>`,
		`<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
		...[
			{
				path: "/",
				changefreq: "weekly",
				priority: "1.0"
			},
			{
				path: "/map",
				changefreq: "always",
				priority: "0.9"
			},
			{
				path: "/vehicles",
				changefreq: "daily",
				priority: "0.8"
			}
		].map((e) => [
			`  <url>`,
			`    <loc>${BASE_URL}${e.path}</loc>`,
			e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
			e.priority ? `    <priority>${e.priority}</priority>` : null,
			`  </url>`
		].filter(Boolean).join("\n")),
		`</urlset>`
	].join("\n");
	return new Response(xml, { headers: {
		"Content-Type": "application/xml",
		"Cache-Control": "public, max-age=3600"
	} });
} } } });
var $$splitComponentImporter$8 = () => import("./register-Cz7EmwgK.mjs");
var Route$8 = createFileRoute("/register")({
	beforeLoad: () => {
		if (typeof window === "undefined") return;
		if (getAuthToken()) throw redirect({ to: "/" });
	},
	head: () => ({ meta: [{ title: "Create account — Fleet Tracker" }] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./login-D0JzhiuC.mjs");
var Route$7 = createFileRoute("/login")({
	beforeLoad: () => {
		if (typeof window === "undefined") return;
		if (getAuthToken()) throw redirect({ to: "/" });
	},
	head: () => ({ meta: [{ title: "Sign in — Fleet Tracker" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./route-BZ80Xigo.mjs");
var Route$6 = createFileRoute("/_authenticated")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("../_authenticated-Dqjc-oub.mjs");
var Route$5 = createFileRoute("/_authenticated/")({
	head: () => ({ meta: [
		{ title: "Dashboard — Fleet Tracker" },
		{
			name: "description",
			content: "Realtime GPS fleet tracking dashboard with live vehicle positions and status."
		},
		{
			property: "og:title",
			content: "Dashboard — Fleet Tracker"
		},
		{
			property: "og:description",
			content: "Realtime GPS fleet tracking dashboard."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./users-CscFgbT-.mjs");
var Route$4 = createFileRoute("/_authenticated/users")({
	head: () => ({ meta: [{ title: "Users — Fleet Tracker" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./profile-BkXcqxfF.mjs");
var Route$3 = createFileRoute("/_authenticated/profile")({
	head: () => ({ meta: [{ title: "Profile — Fleet Tracker" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./map-DKn1x_W-.mjs");
var Route$2 = createFileRoute("/_authenticated/map")({
	head: () => ({ meta: [
		{ title: "Live Map — Fleet Tracker" },
		{
			name: "description",
			content: "Realtime map of all fleet vehicles updating live via WebSocket."
		},
		{
			property: "og:title",
			content: "Live Map — Fleet Tracker"
		},
		{
			property: "og:description",
			content: "Realtime map of all fleet vehicles."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./vehicles.index-CyjqiFU4.mjs");
var Route$1 = createFileRoute("/_authenticated/vehicles/")({
	head: () => ({ meta: [
		{ title: "Vehicles — Fleet Tracker" },
		{
			name: "description",
			content: "Searchable list of all fleet vehicles with live status and speed."
		},
		{
			property: "og:title",
			content: "Vehicles — Fleet Tracker"
		},
		{
			property: "og:description",
			content: "Searchable list of all fleet vehicles."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./vehicles._id.playback-Q4a6xIrx.mjs");
var Route = createFileRoute("/_authenticated/vehicles/$id/playback")({
	beforeLoad: ({ params }) => {
		throw redirect({
			to: "/vehicles/$id/history",
			params: { id: params.id }
		});
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var SitemapDotxmlRoute = Route$9.update({
	id: "/sitemap.xml",
	path: "/sitemap.xml",
	getParentRoute: () => Route$10
});
var RegisterRoute = Route$8.update({
	id: "/register",
	path: "/register",
	getParentRoute: () => Route$10
});
var LoginRoute = Route$7.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$10
});
var AuthenticatedRouteRoute = Route$6.update({
	id: "/_authenticated",
	getParentRoute: () => Route$10
});
var AuthenticatedIndexRoute = Route$5.update({
	id: "/",
	path: "/",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedUsersRoute = Route$4.update({
	id: "/users",
	path: "/users",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedProfileRoute = Route$3.update({
	id: "/profile",
	path: "/profile",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedMapRoute = Route$2.update({
	id: "/map",
	path: "/map",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedVehiclesIndexRoute = Route$1.update({
	id: "/vehicles/",
	path: "/vehicles/",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedVehiclesIdIndexRoute = Route$11.update({
	id: "/vehicles/$id/",
	path: "/vehicles/$id/",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedVehiclesIdPlaybackRoute = Route.update({
	id: "/vehicles/$id/playback",
	path: "/vehicles/$id/playback",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRouteRouteChildren = {
	AuthenticatedMapRoute,
	AuthenticatedProfileRoute,
	AuthenticatedUsersRoute,
	AuthenticatedIndexRoute,
	AuthenticatedVehiclesIndexRoute,
	AuthenticatedVehiclesIdHistoryRoute: Route$12.update({
		id: "/vehicles/$id/history",
		path: "/vehicles/$id/history",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedVehiclesIdPlaybackRoute,
	AuthenticatedVehiclesIdIndexRoute
};
var rootRouteChildren = {
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	LoginRoute,
	RegisterRoute,
	SitemapDotxmlRoute
};
var routeTree = Route$10._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
