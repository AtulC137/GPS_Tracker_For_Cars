import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicles._id.history-DrB1Fgox.js
var $$splitComponentImporter = () => import("./vehicles._id.history-CDT_DTg0.mjs");
var Route = createFileRoute("/_authenticated/vehicles/$id/history")({
	head: () => ({ meta: [{ title: "History & Analysis — Fleet Tracker" }, {
		name: "description",
		content: "View historical GPS routes, trip analysis, and playback for a vehicle."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
