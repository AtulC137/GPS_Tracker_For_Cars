import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicleStore-CQijUHLr.js
var useVehicleStore = create((set) => ({
	positions: {},
	wsConnected: false,
	lastEventAt: null,
	updatePosition: (event) => set((state) => {
		const prev = state.positions[event.vehicleId];
		return {
			lastEventAt: Date.now(),
			positions: {
				...state.positions,
				[event.vehicleId]: {
					latitude: event.latitude,
					longitude: event.longitude,
					speed: event.speed,
					heading: event.heading,
					lastSeenAt: event.lastSeenAt,
					status: prev?.status ?? "online"
				}
			}
		};
	}),
	updateStatus: (event) => set((state) => {
		const prev = state.positions[event.vehicleId];
		if (!prev) return state;
		return {
			lastEventAt: Date.now(),
			positions: {
				...state.positions,
				[event.vehicleId]: {
					...prev,
					status: event.status
				}
			}
		};
	}),
	syncFromVehicles: (vehicles) => set((state) => {
		const positions = { ...state.positions };
		for (const v of vehicles) {
			const s = v.currentState;
			if (s && positions[v.id] === void 0) positions[v.id] = {
				latitude: s.latitude,
				longitude: s.longitude,
				speed: s.speed,
				heading: s.heading,
				lastSeenAt: s.lastSeenAt,
				status: s.status
			};
		}
		return { positions };
	}),
	setConnected: (connected) => set({ wsConnected: connected })
}));
/** Merge API current state with realtime Zustand overlay. */
function mergedPosition(vehicle, live) {
	if (live) return live;
	if (vehicle?.currentState) {
		const s = vehicle.currentState;
		return {
			latitude: s.latitude,
			longitude: s.longitude,
			speed: s.speed,
			heading: s.heading,
			lastSeenAt: s.lastSeenAt,
			status: s.status
		};
	}
}
//#endregion
export { useVehicleStore as n, mergedPosition as t };
