import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as useVehicleStore } from "./vehicleStore-CQijUHLr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useMergedVehicles-kPiaX86R.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/** Combine the API vehicle list with the realtime Zustand overlay. */
function useMergedVehicles(vehicles) {
	const positions = useVehicleStore((s) => s.positions);
	return (0, import_react.useMemo)(() => {
		return (vehicles ?? []).map((v) => ({
			...v,
			live: positions[v.id] ?? v.currentState ?? void 0
		}));
	}, [vehicles, positions]);
}
//#endregion
export { useMergedVehicles as t };
