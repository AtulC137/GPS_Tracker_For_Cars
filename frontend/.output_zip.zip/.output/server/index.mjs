globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"19-yHADZo6lKl+mSNPU9098EiqzPCE\"",
		"mtime": "2026-06-16T11:02:55.851Z",
		"size": 25,
		"path": "../public/robots.txt"
	},
	"/assets/FleetMap-Cw_vEqHl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8cc-aoL22n5ZWDIK3/ANkKs4LdlYv5k\"",
		"mtime": "2026-06-16T11:02:55.081Z",
		"size": 2252,
		"path": "../public/assets/FleetMap-Cw_vEqHl.js"
	},
	"/assets/VehicleStatusBadge-_uS5L7iR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"226-fL7J8BaSIE81FId8GSEYEKB5l1s\"",
		"mtime": "2026-06-16T11:02:55.081Z",
		"size": 550,
		"path": "../public/assets/VehicleStatusBadge-_uS5L7iR.js"
	},
	"/assets/_authenticated-c-Guq_nC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"104a-WOeh17sL3bJxIliKPpw/Mc/HAkg\"",
		"mtime": "2026-06-16T11:02:55.081Z",
		"size": 4170,
		"path": "../public/assets/_authenticated-c-Guq_nC.js"
	},
	"/assets/arrow-left-tzjZZShG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-AU7kBd9eBIQlWbGnjIrcbefVqR8\"",
		"mtime": "2026-06-16T11:02:55.081Z",
		"size": 165,
		"path": "../public/assets/arrow-left-tzjZZShG.js"
	},
	"/assets/client-CrY19GUP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"104b3-63p7r3ZkO2k3nCFIKOn94tUWBFY\"",
		"mtime": "2026-06-16T11:02:55.081Z",
		"size": 66739,
		"path": "../public/assets/client-CrY19GUP.js"
	},
	"/assets/createLucideIcon-deCkT3bJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a6-UQWA1Z4BWWVs1CHjIpzH6x0kTwU\"",
		"mtime": "2026-06-16T11:02:55.082Z",
		"size": 1190,
		"path": "../public/assets/createLucideIcon-deCkT3bJ.js"
	},
	"/assets/format-D2sGkcQe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"473-0sz0AxijFWfY9M3JhUs+3lKF/6o\"",
		"mtime": "2026-06-16T11:02:55.082Z",
		"size": 1139,
		"path": "../public/assets/format-D2sGkcQe.js"
	},
	"/assets/gauge-BkVkiKb8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b0-3xoEKhL6Z4ElS9SduUNzRvCtA7k\"",
		"mtime": "2026-06-16T11:02:55.082Z",
		"size": 176,
		"path": "../public/assets/gauge-BkVkiKb8.js"
	},
	"/assets/label-enPr-Fp6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1594-6YOvIDGl6v8CYycXzIDk9+351mg\"",
		"mtime": "2026-06-16T11:02:55.082Z",
		"size": 5524,
		"path": "../public/assets/label-enPr-Fp6.js"
	},
	"/assets/link-ITxB0P9L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"58b0-Gcg21q0oK37MT7D8KhyY59nlM5U\"",
		"mtime": "2026-06-16T11:02:55.083Z",
		"size": 22704,
		"path": "../public/assets/link-ITxB0P9L.js"
	},
	"/assets/login-DRd0Oh1o.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a0-IJqZN0RE6aFjIP23m18I9j9INZ4\"",
		"mtime": "2026-06-16T11:02:55.083Z",
		"size": 2208,
		"path": "../public/assets/login-DRd0Oh1o.js"
	},
	"/assets/map-BKxqs4ou.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"864-NQlKBncPOnBdW2nhJTrL7kSkRxs\"",
		"mtime": "2026-06-16T11:02:55.083Z",
		"size": 2148,
		"path": "../public/assets/map-BKxqs4ou.js"
	},
	"/assets/index-8Mwg41Z9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4d2a3-C1SH3VHkL25MDcmS7EVhGFCV+sg\"",
		"mtime": "2026-06-16T11:02:55.076Z",
		"size": 316067,
		"path": "../public/assets/index-8Mwg41Z9.js"
	},
	"/assets/map-pin-LhR3ukPj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"103-/BD9XbcppwUEEykViM6A9GKWM+4\"",
		"mtime": "2026-06-16T11:02:55.083Z",
		"size": 259,
		"path": "../public/assets/map-pin-LhR3ukPj.js"
	},
	"/assets/maplibre-gl-B2k4QVOw.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"110b0-ktCrTpfc4yMYyf4bIOXbtYXFctY\"",
		"mtime": "2026-06-16T11:02:55.089Z",
		"size": 69808,
		"path": "../public/assets/maplibre-gl-B2k4QVOw.css"
	},
	"/assets/matchContext-Bu-3Akaj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c6-y1V8AOfBoUh02CjkQ1L+BCzZnVw\"",
		"mtime": "2026-06-16T11:02:55.084Z",
		"size": 710,
		"path": "../public/assets/matchContext-Bu-3Akaj.js"
	},
	"/assets/navigation-C4p1oyr_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"94-R8V0CgRw3MShMVl71RC0dRM/3Bg\"",
		"mtime": "2026-06-16T11:02:55.086Z",
		"size": 148,
		"path": "../public/assets/navigation-C4p1oyr_.js"
	},
	"/assets/profile-DYqJ_GE3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a8-nqb3c4U8ql/LRuO70Jh/CFEAaf8\"",
		"mtime": "2026-06-16T11:02:55.086Z",
		"size": 2216,
		"path": "../public/assets/profile-DYqJ_GE3.js"
	},
	"/assets/register-BowL5zbG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf5-vO3WrEXQOKQyl4+6/VZOGPfglMQ\"",
		"mtime": "2026-06-16T11:02:55.086Z",
		"size": 3317,
		"path": "../public/assets/register-BowL5zbG.js"
	},
	"/assets/spinner-DJ55cKAp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c31-wxEX/R0Bj5PPlYGXiVm5WJCjHsI\"",
		"mtime": "2026-06-16T11:02:55.086Z",
		"size": 3121,
		"path": "../public/assets/spinner-DJ55cKAp.js"
	},
	"/assets/route-Cn96KX32.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a45-vwD8RfEcLw67LsWgbAmvR8GLphI\"",
		"mtime": "2026-06-16T11:02:55.086Z",
		"size": 6725,
		"path": "../public/assets/route-Cn96KX32.js"
	},
	"/assets/truck-D_QCmOGD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"196-1DzHhFKC0Bp/PgsEs1os+NxMnpc\"",
		"mtime": "2026-06-16T11:02:55.087Z",
		"size": 406,
		"path": "../public/assets/truck-D_QCmOGD.js"
	},
	"/assets/styles-BPmujWbG.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"13555-QyWEqKRUW49u9d/ZWb5dXtXZO2U\"",
		"mtime": "2026-06-16T11:02:55.089Z",
		"size": 79189,
		"path": "../public/assets/styles-BPmujWbG.css"
	},
	"/assets/maplibre-gl-D7QpM4b2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fae0e-J34DZ9a2Gk4MGcVaB0MBGsSR62M\"",
		"mtime": "2026-06-16T11:02:55.083Z",
		"size": 1027598,
		"path": "../public/assets/maplibre-gl-D7QpM4b2.js"
	},
	"/assets/useMergedVehicles-XmBlcNHt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f9-O010FVH6hPIgACwxjovSw47cbGw\"",
		"mtime": "2026-06-16T11:02:55.087Z",
		"size": 249,
		"path": "../public/assets/useMergedVehicles-XmBlcNHt.js"
	},
	"/assets/useRouter-D_ZGALQC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1052-BZXTBHN6F7TiD9GXFquXtIclJ3w\"",
		"mtime": "2026-06-16T11:02:55.087Z",
		"size": 4178,
		"path": "../public/assets/useRouter-D_ZGALQC.js"
	},
	"/assets/useVehicles-BvK5Zom2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2725-uYoV59VNDnuBXw6srzYAUpUrJps\"",
		"mtime": "2026-06-16T11:02:55.087Z",
		"size": 10021,
		"path": "../public/assets/useVehicles-BvK5Zom2.js"
	},
	"/assets/users-B4D01jHw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ad2-u+6CMFdGayBHQz9aIWyQrF/OJlI\"",
		"mtime": "2026-06-16T11:02:55.087Z",
		"size": 6866,
		"path": "../public/assets/users-B4D01jHw.js"
	},
	"/assets/utils-B6KiDbIe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6a7d-iNkBSvaSyIjvZOzWoTvEa49qwcI\"",
		"mtime": "2026-06-16T11:02:55.087Z",
		"size": 27261,
		"path": "../public/assets/utils-B6KiDbIe.js"
	},
	"/assets/vehicleStore-BQivdLGV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"641-nwsfRsIZWclLipQ3qMKHkJAphDM\"",
		"mtime": "2026-06-16T11:02:55.087Z",
		"size": 1601,
		"path": "../public/assets/vehicleStore-BQivdLGV.js"
	},
	"/assets/vehicles._id.history-BJhZ1uky.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3601-VKHiTXQ/C3f2taLL9FLMxaHGdHQ\"",
		"mtime": "2026-06-16T11:02:55.088Z",
		"size": 13825,
		"path": "../public/assets/vehicles._id.history-BJhZ1uky.js"
	},
	"/assets/vehicles._id.index-DAKqqvsn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15d6-uTme9FaDb2X4j/U1KrQdW/Mm2o8\"",
		"mtime": "2026-06-16T11:02:55.088Z",
		"size": 5590,
		"path": "../public/assets/vehicles._id.index-DAKqqvsn.js"
	},
	"/assets/vehicles._id.playback-DJ7LAi8J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26-SoFMfAHVJ5oqB5t+mpFRoQvFIoc\"",
		"mtime": "2026-06-16T11:02:55.088Z",
		"size": 38,
		"path": "../public/assets/vehicles._id.playback-DJ7LAi8J.js"
	},
	"/assets/vehicles.index-6_gONoHW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b7d4-WXoxh4eUH1Q0k4D+tb/Zch8DC1M\"",
		"mtime": "2026-06-16T11:02:55.088Z",
		"size": 47060,
		"path": "../public/assets/vehicles.index-6_gONoHW.js"
	},
	"/assets/wifi-Cj8x2l29.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2af-6DiAz3//+He6ATOD6OsARg+vRTM\"",
		"mtime": "2026-06-16T11:02:55.088Z",
		"size": 687,
		"path": "../public/assets/wifi-Cj8x2l29.js"
	},
	"/assets/x-35hMZT4w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-8xMqt1ChZiz/Q7hiOnzRfRL9hwA\"",
		"mtime": "2026-06-16T11:02:55.088Z",
		"size": 154,
		"path": "../public/assets/x-35hMZT4w.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}], $1 = [{
		name: "headers",
		route: "/**",
		handler: headers,
		options: { "Content-Security-Policy": "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https://tile.openstreetmap.org; connect-src 'self' http://localhost:3000 ws://localhost:3000/ws https://tile.openstreetmap.org; worker-src 'self' blob:; font-src 'self' data:" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		r.unshift({
			data: $1,
			params: { "_": s.slice(1).join("/") }
		});
		return r;
	};
})();
var _lazy_jPnBRt = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_jPnBRt
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
