import { r as __toESM } from "../_runtime.mjs";
import { r as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as literalType, c as stringType, i as enumType, s as objectType } from "../_libs/zod.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as clearAuthToken, d as setAuthToken, f as setUnauthorizedHandler, l as patch, o as get, s as getAuthToken, t as ApiError, u as post } from "./client-DUvhSboa.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AuthContext-CIziQDdM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var UserSchema = objectType({
	id: stringType(),
	email: stringType(),
	name: stringType().nullable().optional(),
	role: enumType(["admin", "viewer"])
});
var OrganizationSchema = objectType({
	id: stringType(),
	name: stringType(),
	slug: stringType()
});
var AuthResponseSchema = objectType({
	token: stringType(),
	user: UserSchema,
	organization: OrganizationSchema
});
var RegisterResponseSchema = objectType({
	user: UserSchema,
	organization: OrganizationSchema,
	status: literalType("pending")
});
var MeResponseSchema = objectType({
	user: UserSchema,
	organization: OrganizationSchema
});
async function login(email, password) {
	const data = await post("/api/v1/auth/login", {
		email,
		password
	});
	return AuthResponseSchema.parse(data);
}
async function register(input) {
	const data = await post("/api/v1/auth/register", input);
	return RegisterResponseSchema.parse(data);
}
function parseMeResponse(data) {
	const parsed = MeResponseSchema.safeParse(data);
	if (!parsed.success) throw new ApiError("Unexpected server response while restoring session.", 0);
	return parsed.data;
}
async function fetchMe() {
	return parseMeResponse(await get("/api/v1/auth/me"));
}
async function updateMe(input) {
	return parseMeResponse(await patch("/api/v1/auth/me", input));
}
var AuthContext = (0, import_react.createContext)(null);
function AuthProvider({ children }) {
	const navigate = useNavigate();
	const [user, setUser] = (0, import_react.useState)(null);
	const [organization, setOrganization] = (0, import_react.useState)(null);
	const [isLoading, setIsLoading] = (0, import_react.useState)(true);
	const [restoreError, setRestoreError] = (0, import_react.useState)(null);
	const logout = (0, import_react.useCallback)(() => {
		clearAuthToken();
		setUser(null);
		setOrganization(null);
		setRestoreError(null);
		navigate({ to: "/login" });
	}, [navigate]);
	const login$1 = (0, import_react.useCallback)(async (email, password) => {
		const result = await login(email, password);
		setAuthToken(result.token);
		setUser(result.user);
		setOrganization(result.organization);
		setRestoreError(null);
		await navigate({ to: "/" });
	}, [navigate]);
	const register$1 = (0, import_react.useCallback)(async (input) => {
		const result = await register(input);
		setAuthToken(result.token);
		setUser(result.user);
		setOrganization(result.organization);
		setRestoreError(null);
		await navigate({ to: "/" });
	}, [navigate]);
	const refreshMe = (0, import_react.useCallback)(async () => {
		const me = await fetchMe();
		setUser(me.user);
		setOrganization(me.organization);
		setRestoreError(null);
	}, []);
	(0, import_react.useEffect)(() => {
		setUnauthorizedHandler(() => {
			setUser(null);
			setOrganization(null);
			setRestoreError(null);
			navigate({ to: "/login" });
		});
	}, [navigate]);
	const restoreSession = (0, import_react.useCallback)(async () => {
		if (!getAuthToken()) {
			setUser(null);
			setOrganization(null);
			setRestoreError(null);
			return;
		}
		setRestoreError(null);
		try {
			const me = await fetchMe();
			setUser(me.user);
			setOrganization(me.organization);
		} catch (err) {
			if (err instanceof ApiError && err.status === 401) {
				clearAuthToken();
				setUser(null);
				setOrganization(null);
				setRestoreError(null);
				return;
			}
			setUser(null);
			setOrganization(null);
			setRestoreError(err instanceof ApiError ? err.message : err instanceof Error ? err.message : "Unable to restore session. Please try again.");
		}
	}, []);
	const retryRestore = (0, import_react.useCallback)(async () => {
		setIsLoading(true);
		await restoreSession();
		setIsLoading(false);
	}, [restoreSession]);
	(0, import_react.useEffect)(() => {
		if (!getAuthToken()) {
			setIsLoading(false);
			return;
		}
		restoreSession().finally(() => setIsLoading(false));
	}, [restoreSession]);
	const value = (0, import_react.useMemo)(() => ({
		user,
		organization,
		isLoading,
		isAuthenticated: Boolean(user && organization),
		restoreError,
		refreshMe,
		retryRestore,
		login: login$1,
		register: register$1,
		logout
	}), [
		user,
		organization,
		isLoading,
		restoreError,
		refreshMe,
		retryRestore,
		login$1,
		register$1,
		logout
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value,
		children
	});
}
function useAuth() {
	const ctx = (0, import_react.useContext)(AuthContext);
	if (!ctx) throw new Error("useAuth must be used within AuthProvider");
	return ctx;
}
//#endregion
export { updateMe as n, useAuth as r, AuthProvider as t };
