import { r as __toESM } from "../_runtime.mjs";
import { r as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { D as ArrowLeft, b as History, g as MapPin, p as Navigation, w as Clock, x as Gauge } from "../_libs/lucide-react.mjs";
import { o as LoadingState, r as ErrorState } from "./spinner-muDgHEuQ.mjs";
import { t as ApiError } from "./client-DUvhSboa.mjs";
import { i as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { a as useVehicle, i as updateVehicle, o as useVehicleLive } from "./useVehicles-Bwt4z13w.mjs";
import { n as useVehicleStore, t as mergedPosition } from "./vehicleStore-CQijUHLr.mjs";
import { a as formatHeading, n as formatDateTime, o as formatSpeed, s as relativeTime, t as formatCoord } from "./format-Dbvgyw5I.mjs";
import { t as VehicleStatusBadge } from "./VehicleStatusBadge-B7pv-ZBP.mjs";
import { t as FleetMap } from "./FleetMap-Wwx9Unqf.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useAuth } from "./AuthContext-CIziQDdM.mjs";
import { n as Input, r as Label, t as Button } from "./label-BxvS4Y9r.mjs";
import { t as Route } from "./vehicles._id.index-BIPcAx1y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicles._id.index-CY8dIapR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VehicleDetailPage({ id }) {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const { data: vehicle, isLoading, isError, error, refetch } = useVehicle(id);
	const { data: live } = useVehicleLive(id);
	const storePos = useVehicleStore((s) => s.positions[id]);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [vehicleName, setVehicleName] = (0, import_react.useState)("");
	const [vehicleNumber, setVehicleNumber] = (0, import_react.useState)("");
	const [saveError, setSaveError] = (0, import_react.useState)(null);
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (live) useVehicleStore.getState().updatePosition({
			type: "vehicle_location_update",
			vehicleId: id,
			latitude: live.latitude,
			longitude: live.longitude,
			speed: live.speed,
			heading: live.heading,
			lastSeenAt: live.lastSeenAt
		});
	}, [live, id]);
	(0, import_react.useEffect)(() => {
		if (!vehicle) return;
		setVehicleName(vehicle.vehicleName);
		setVehicleNumber(vehicle.vehicleNumber);
	}, [vehicle]);
	const isAdmin = user?.role === "admin";
	const canSave = (0, import_react.useMemo)(() => {
		if (!isAdmin) return false;
		if (!editing) return false;
		const name = vehicleName.trim();
		const number = vehicleNumber.trim();
		return name.length > 0 && number.length > 0;
	}, [
		isAdmin,
		editing,
		vehicleName,
		vehicleNumber
	]);
	const pos = storePos ?? mergedPosition(vehicle, void 0);
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, { label: "Loading vehicle…" });
	if (isError || !vehicle) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
		message: error?.message,
		onRetry: () => refetch()
	});
	const merged = [{
		...vehicle,
		live: pos ?? void 0
	}];
	const onSave = async () => {
		if (!canSave) return;
		setSaving(true);
		setSaveError(null);
		try {
			await updateVehicle(id, {
				vehicleName: vehicleName.trim(),
				vehicleNumber: vehicleNumber.trim()
			});
			await Promise.all([queryClient.invalidateQueries({ queryKey: ["vehicles"] }), queryClient.invalidateQueries({ queryKey: ["vehicle", id] })]);
			setEditing(false);
		} catch (err) {
			setSaveError(err instanceof ApiError ? err.message : "Unable to save vehicle.");
		} finally {
			setSaving(false);
		}
	};
	const onCancel = () => {
		setVehicleName(vehicle.vehicleName);
		setVehicleNumber(vehicle.vehicleNumber);
		setSaveError(null);
		setEditing(false);
	};
	const info = [
		{
			icon: MapPin,
			label: "Location",
			value: formatCoord(pos?.latitude, pos?.longitude)
		},
		{
			icon: Gauge,
			label: "Speed",
			value: formatSpeed(pos?.speed)
		},
		{
			icon: Navigation,
			label: "Heading",
			value: formatHeading(pos?.heading)
		},
		{
			icon: Clock,
			label: "Last Seen",
			value: `${relativeTime(pos?.lastSeenAt)} (${formatDateTime(pos?.lastSeenAt)})`
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl space-y-6 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/vehicles",
				className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back to vehicles"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-bold tracking-tight",
						children: vehicle.vehicleName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleStatusBadge, { status: pos?.status })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						vehicle.vehicleNumber,
						" · Device ",
						vehicle.deviceId
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						isAdmin && !editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => {
								setSaveError(null);
								setEditing(true);
							},
							children: "Edit details"
						}),
						isAdmin && editing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: onCancel,
							disabled: saving,
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							onClick: onSave,
							disabled: !canSave || saving,
							children: saving ? "Saving…" : "Save"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/vehicles/$id/history",
							params: { id },
							className: "inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "h-4 w-4" }), " History & Analysis"]
						})
					]
				})]
			}),
			isAdmin && editing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border bg-card p-4 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "vehicleName",
							children: "Vehicle name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "vehicleName",
							value: vehicleName,
							onChange: (e) => setVehicleName(e.target.value),
							placeholder: "e.g. Delivery Van 3"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "vehicleNumber",
							children: "Vehicle number"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "vehicleNumber",
							value: vehicleNumber,
							onChange: (e) => setVehicleNumber(e.target.value),
							placeholder: "e.g. MH12AB1234"
						})]
					})]
				}), saveError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive",
					children: saveError
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-6 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3 lg:col-span-1",
					children: info.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3 rounded-xl border border-border bg-card p-4 shadow-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(i.icon, { className: "h-5 w-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: i.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: i.value
						})] })]
					}, i.label))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-xl border border-border bg-card shadow-sm lg:col-span-2",
					children: pos ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FleetMap, {
						vehicles: merged,
						focusId: id,
						className: "h-[440px] w-full"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-[440px] items-center justify-center text-sm text-muted-foreground",
						children: "No location data available."
					})
				})]
			})
		]
	});
}
function VehicleDetailRoute() {
	const { id } = Route.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleDetailPage, { id });
}
//#endregion
export { VehicleDetailRoute as component };
