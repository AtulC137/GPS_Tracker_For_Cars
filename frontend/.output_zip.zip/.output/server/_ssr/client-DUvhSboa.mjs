//#region node_modules/.nitro/vite/services/ssr/assets/client-DUvhSboa.js
var API_URL = "http://localhost:3000".replace(/\/$/, "") || "http://localhost:3000";
var WS_URL = "ws://localhost:3000/ws";
var DEFAULT_CENTER = [73.8567, 18.5204];
var MAP_STYLE = {
	version: 8,
	sources: { osm: {
		type: "raster",
		tiles: ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
		tileSize: 256,
		attribution: "© OpenStreetMap contributors"
	} },
	layers: [{
		id: "osm",
		type: "raster",
		source: "osm"
	}]
};
var AUTH_TOKEN_KEY = "fleet_auth_token";
/** True in the browser; false during TanStack Start SSR. */
function isBrowser() {
	return typeof window !== "undefined";
}
function getAuthToken() {
	if (!isBrowser()) return null;
	return localStorage.getItem(AUTH_TOKEN_KEY);
}
function setAuthToken(token) {
	localStorage.setItem(AUTH_TOKEN_KEY, token);
}
function clearAuthToken() {
	localStorage.removeItem(AUTH_TOKEN_KEY);
}
function getWsUrlWithToken(baseUrl, token) {
	const url = new URL(baseUrl);
	url.searchParams.set("token", token);
	return url.toString();
}
var ApiError = class extends Error {
	status;
	constructor(message, status) {
		super(message);
		this.name = "ApiError";
		this.status = status;
	}
};
var onUnauthorized = null;
function setUnauthorizedHandler(handler) {
	onUnauthorized = handler;
}
function authHeaders() {
	const headers = { Accept: "application/json" };
	const token = getAuthToken();
	if (token) headers.Authorization = `Bearer ${token}`;
	return headers;
}
async function handleResponse(res) {
	if (res.status === 401) {
		if (getAuthToken()) {
			clearAuthToken();
			onUnauthorized?.();
		}
	}
	if (!res.ok) {
		let detail = "";
		try {
			detail = (await res.json()).error ?? "";
		} catch {
			try {
				detail = await res.text();
			} catch {}
		}
		throw new ApiError(detail || `Request failed (${res.status})`, res.status);
	}
	return await res.json();
}
async function get(path) {
	let res;
	try {
		res = await fetch(`${API_URL}${path}`, { headers: authHeaders() });
	} catch {
		throw new ApiError(`Network error reaching ${API_URL}. Is the backend running?`, 0);
	}
	return handleResponse(res);
}
async function post(path, body) {
	let res;
	try {
		res = await fetch(`${API_URL}${path}`, {
			method: "POST",
			headers: {
				...authHeaders(),
				"Content-Type": "application/json"
			},
			body: JSON.stringify(body)
		});
	} catch {
		throw new ApiError(`Network error reaching ${API_URL}. Is the backend running?`, 0);
	}
	return handleResponse(res);
}
async function patch(path, body) {
	let res;
	try {
		res = await fetch(`${API_URL}${path}`, {
			method: "PATCH",
			headers: {
				...authHeaders(),
				"Content-Type": "application/json"
			},
			body: JSON.stringify(body)
		});
	} catch {
		throw new ApiError(`Network error reaching ${API_URL}. Is the backend running?`, 0);
	}
	return handleResponse(res);
}
//#endregion
export { clearAuthToken as a, getWsUrlWithToken as c, setAuthToken as d, setUnauthorizedHandler as f, WS_URL as i, patch as l, DEFAULT_CENTER as n, get as o, MAP_STYLE as r, getAuthToken as s, ApiError as t, post as u };
