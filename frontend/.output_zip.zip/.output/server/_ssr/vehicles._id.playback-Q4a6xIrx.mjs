//#region node_modules/.nitro/vite/services/ssr/assets/vehicles._id.playback-Q4a6xIrx.js
var SplitComponent = () => null;
//#endregion
export { SplitComponent as component };
