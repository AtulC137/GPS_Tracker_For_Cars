import { t as cn } from "./utils-C_uf36nf.mjs";
import { r as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/VehicleStatusBadge-B7pv-ZBP.js
var import_jsx_runtime = require_jsx_runtime();
function VehicleStatusBadge({ status }) {
	const online = status === "online";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium", online ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400" : "bg-muted text-muted-foreground"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1.5 w-1.5 rounded-full", online ? "bg-emerald-500 animate-pulse shadow-[0_0_0_3px_rgba(16,185,129,0.15)]" : "bg-muted-foreground/60") }), online ? "Online" : "Offline"]
	});
}
//#endregion
export { VehicleStatusBadge as t };
